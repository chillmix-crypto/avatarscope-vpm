using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Session-scope cache of real AssetBundle build results. Avoids re-running the slow
    /// VRC SDK build pipeline when nothing relevant to the bundle has changed.
    ///
    /// Cache key = hash of (all asset paths the avatar references) + (mtime of each).
    /// SaveAndReimport (which the Lossless Optimizer uses) updates mtime, so the cache
    /// invalidates automatically after any optimization.
    ///
    /// Lives in a static field — cleared on Unity restart.
    /// </summary>
    public static class BundleSizeCache
    {
        private static string _lastHash;
        private static long   _lastBundleBytes;
        private static string _lastMethod;

        public static bool TryGet(GameObject avatar, out long bundleBytes, out string method)
        {
            bundleBytes = 0;
            method = null;
            if (avatar == null) return false;
            string h = ComputeHash(avatar);
            if (h == _lastHash)
            {
                bundleBytes = _lastBundleBytes;
                method = _lastMethod;
                return true;
            }
            return false;
        }

        public static void Set(GameObject avatar, long bundleBytes, string method)
        {
            if (avatar == null) return;
            _lastHash = ComputeHash(avatar);
            _lastBundleBytes = bundleBytes;
            _lastMethod = method;
        }

        public static void Invalidate()
        {
            _lastHash = null;
            _lastBundleBytes = 0;
            _lastMethod = null;
        }

        // -------- Hash --------

        private static string ComputeHash(GameObject avatar)
        {
            var sb = new StringBuilder(8192);
            var visited = new HashSet<string>();

            // Hierarchy fingerprint: name+type per component, so adding/removing a component invalidates.
            foreach (var t in avatar.GetComponentsInChildren<Transform>(true))
            {
                if (t == null) continue;
                sb.Append(t.gameObject.name).Append('/');
                foreach (var c in t.GetComponents<Component>())
                {
                    if (c == null) { sb.Append("?,"); continue; }
                    sb.Append(c.GetType().Name).Append(',');
                }
                sb.Append('|');
            }

            // Asset dependencies: path + mtime. SaveAndReimport bumps mtime so the cache
            // is invalidated whenever the Lossless Optimizer changes import settings.
            foreach (var comp in avatar.GetComponentsInChildren<Component>(true))
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null) continue;
                    string path = AssetDatabase.GetAssetPath(obj);
                    if (string.IsNullOrEmpty(path) || visited.Contains(path)) continue;
                    visited.Add(path);
                    sb.Append(path).Append(':');
                    try
                    {
                        var fi = new FileInfo(path);
                        if (fi.Exists) sb.Append(fi.LastWriteTimeUtc.Ticks);
                    }
                    catch { /* ignore */ }
                    sb.Append('|');
                }
            }

            using (var sha = SHA256.Create())
            {
                var hashBytes = sha.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString()));
                return System.Convert.ToBase64String(hashBytes);
            }
        }
    }
}

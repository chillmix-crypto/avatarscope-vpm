using System.IO;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Builds a real Unity AssetBundle from the avatar and measures the resulting file size.
    /// This is the most accurate Download Size estimate possible without uploading to VRChat,
    /// because it goes through Unity's full compression pipeline (the same one VRChat uses).
    ///
    /// Cost: 3-30 seconds per measurement. Used opt-in via the "Measure real size" toggle.
    /// </summary>
    public static class AssetBundleSizeMeasurer
    {
        private const string TempAssetFolderName = "_AvatarScope_TempBundle";
        private const string TempAssetFolderPath = "Assets/_AvatarScope_TempBundle";
        private const string TempPrefabName      = "_avatarscope_target.prefab";
        private const string TempOutputDir       = "Temp/AvatarScopeBundleOutput";
        private const string TempBundleName      = "avatarscope_temp_bundle.unity3d";

        public struct Result
        {
            public bool   Success;
            public long   BundleSizeBytes;
            public string FailureReason;
            public double DurationSeconds;
            public string MethodUsed;   // "VRC SDK exact" or "Unity BuildPipeline"
        }

        /// <summary>
        /// Builds a one-asset AssetBundle from a clone of <paramref name="sourceAvatar"/> and
        /// returns the on-disk size of the resulting bundle (in bytes).
        /// The source avatar in the user's scene is NOT modified.
        /// </summary>
        public static Result Measure(GameObject sourceAvatar, BuildTarget target)
        {
            var r = new Result();
            if (sourceAvatar == null)
            {
                r.FailureReason = "Avatar is null.";
                return r;
            }

            if (!BuildPipeline.IsBuildTargetSupported(GetGroup(target), target))
            {
                r.FailureReason = $"Build target {target} is not installed (open Unity Hub > Add Modules).";
                return r;
            }

            var sw = System.Diagnostics.Stopwatch.StartNew();

            // (B) First try VRChat SDK's exact build pipeline — this matches VRChat's reported
            // download size byte-for-byte when available.
            try
            {
                var sdkResult = VRCSdkBuilderIntegration.TryBuildExact(sourceAvatar);
                if (sdkResult.Success)
                {
                    sw.Stop();
                    r.Success = true;
                    r.BundleSizeBytes = sdkResult.BundleSizeBytes;
                    r.MethodUsed = $"VRC SDK exact ({sdkResult.MethodUsed})";
                    r.DurationSeconds = sw.Elapsed.TotalSeconds;
                    return r;
                }
            }
            catch (System.Exception e)
            {
                Debug.LogWarning($"[AvatarScope] VRC SDK exact build threw: {e.Message}. Falling back to Unity BuildPipeline.");
            }

            // (A) Fall back to Unity's BuildPipeline with VRChat-matching options.
            r.MethodUsed = "Unity BuildPipeline (LZMA + StripTypeTree)";
            GameObject clone = null;
            bool tempFolderCreated = false;

            try
            {
                // 1. Clone the avatar so we never touch the user's scene object.
                clone = Object.Instantiate(sourceAvatar);
                clone.transform.position = new Vector3(99999, -99999, 99999);
                clone.name = "__AvatarScope_BundleBuildClone";

                // 2. Prepare temp asset folder.
                if (!AssetDatabase.IsValidFolder(TempAssetFolderPath))
                {
                    AssetDatabase.CreateFolder("Assets", TempAssetFolderName);
                    tempFolderCreated = true;
                }

                // 3. Save clone as temp prefab (no connection back to scene).
                string prefabPath = $"{TempAssetFolderPath}/{TempPrefabName}";
                bool saveOK;
                var prefab = PrefabUtility.SaveAsPrefabAsset(clone, prefabPath, out saveOK);
                if (!saveOK || prefab == null)
                {
                    r.FailureReason = "Failed to save temporary prefab.";
                    return r;
                }

                // 4. Prepare output folder.
                if (Directory.Exists(TempOutputDir)) Directory.Delete(TempOutputDir, true);
                Directory.CreateDirectory(TempOutputDir);

                // 5. Build the AssetBundle.
                var bundleBuild = new AssetBundleBuild
                {
                    assetBundleName = TempBundleName,
                    assetNames = new[] { prefabPath },
                };

                // Match VRChat's avatar build options as closely as possible.
                // VRChat ships avatars as LZMA-compressed bundles with type tree stripped.
                //   - None                 = LZMA (Unity default)
                //   - DisableWriteTypeTree = strip Unity type info (~5-15% smaller)
                //   - StrictMode           = fail on warning, ensures clean output
                // (DeterministicAssetBundle is always enabled in modern Unity, no longer a flag.)
                var options = BuildAssetBundleOptions.None
                              | BuildAssetBundleOptions.DisableWriteTypeTree
                              | BuildAssetBundleOptions.StrictMode;

                var manifest = BuildPipeline.BuildAssetBundles(
                    TempOutputDir,
                    new[] { bundleBuild },
                    options,
                    target);

                if (manifest == null)
                {
                    r.FailureReason = "AssetBundle build returned null (see Console for build errors).";
                    return r;
                }

                // 6. Measure the resulting file.
                string bundleFile = Path.Combine(TempOutputDir, TempBundleName);
                if (!File.Exists(bundleFile))
                {
                    r.FailureReason = $"Expected bundle file not found at {bundleFile}.";
                    return r;
                }
                r.BundleSizeBytes = new FileInfo(bundleFile).Length;
                r.Success = true;
                return r;
            }
            catch (System.Exception e)
            {
                r.FailureReason = e.Message;
                return r;
            }
            finally
            {
                // 7. Cleanup in a fixed order: clone first, then asset folder, then output dir.
                if (clone != null)
                {
                    try { Object.DestroyImmediate(clone); } catch { /* ignore */ }
                }
                if (tempFolderCreated && AssetDatabase.IsValidFolder(TempAssetFolderPath))
                {
                    try { AssetDatabase.DeleteAsset(TempAssetFolderPath); } catch { /* ignore */ }
                }
                if (Directory.Exists(TempOutputDir))
                {
                    try { Directory.Delete(TempOutputDir, true); } catch { /* ignore */ }
                }
                sw.Stop();
                r.DurationSeconds = sw.Elapsed.TotalSeconds;
            }
        }

        private static BuildTargetGroup GetGroup(BuildTarget t)
        {
            switch (t)
            {
                case BuildTarget.Android:               return BuildTargetGroup.Android;
                case BuildTarget.iOS:                   return BuildTargetGroup.iOS;
                case BuildTarget.StandaloneOSX:         return BuildTargetGroup.Standalone;
                case BuildTarget.StandaloneLinux64:     return BuildTargetGroup.Standalone;
                default:                                return BuildTargetGroup.Standalone;
            }
        }
    }
}

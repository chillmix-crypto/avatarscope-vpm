using System;
using System.Collections.Generic;
using Chill.AvatarScope.Editor.Analyzers;
using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Avatars.Components;
#endif

namespace Chill.AvatarScope.Editor.Window
{
    public class AvatarScopeWindow : EditorWindow
    {
        private const string UxmlGuidSearch = "AvatarScopeView";
        private const string UssGuidSearch  = "AvatarScopeStyle";

        // Performance Rank thresholds (VRChat "Good" PC tier as reference).
        private const int    PolyBudget    = 70000;
        private const int    MatBudget     = 8;
        private const int    PhysBoneBudget= 16;
        private const int    ColliderBudget= 16;
        private const int    KeywordBudget = 64;
        private const long   DownloadBudgetBytes = 50L * 1024 * 1024; // 50 MB recommended
        private const long   VRAMBudgetBytes     = 110L * 1024 * 1024;

        private GameObject _avatar;
        private MetricsResult _result;
        private DateTime _lastRefresh = DateTime.MinValue;
        private int _changesSinceRefresh;

        private BreakdownViewMode _viewMode = BreakdownViewMode.GameObject;
        private BreakdownSortMode _sortMode = BreakdownSortMode.FileSize;
        private bool _hideSmall;
        private bool _simulateMA = true;
        // Always measure real size — toggle removed in v0.10. First build is slow (~10-30s)
        // but Unity caches the bundle so subsequent Refreshes are near-instant.
        private bool _measureRealSize = true;

        // UI
        private ObjectField _avatarField;
        private Button _refreshBtn;
        private Button _losslessBtn;
        private Button _viewGoBtn;
        private Button _viewAssetBtn;
        private EnumField _sortField;
        private Toggle _hideToggle;
        private Toggle _maSimToggle;
        private Label _lastRefreshLabel;
        private Label _changesBadge;
        private Label _maStatusBadge;
        private Label _realStatusBadge;
        private Label _totalLabel;
        private VisualElement _treeRoot;
        private Label _optimizeTarget;
        private VisualElement _optimizeActions;
        private UnityEngine.Object _selectedAsset;

        [MenuItem("Tools/AvatarScope/Open Window", false, 100)]
        public static void Open()
        {
            var w = GetWindow<AvatarScopeWindow>();
            w.titleContent = new GUIContent("AvatarScope");
            w.minSize = new Vector2(420, 480);
            w.Show();
        }

        private void OnEnable()
        {
            var root = rootVisualElement;
            root.Clear();

            var uxml = LoadAsset<VisualTreeAsset>(UxmlGuidSearch, "uxml");
            var uss  = LoadAsset<StyleSheet>(UssGuidSearch, "uss");

            if (uxml == null)
            {
                root.Add(new Label("AvatarScope: AvatarScopeView.uxml not found."));
                return;
            }

            uxml.CloneTree(root);
            if (uss != null) root.styleSheets.Add(uss);

            BindUI(root);
            RegisterEvents();
            TryAutoBindAvatar();
            ClearResultDisplay();

            EditorApplication.hierarchyChanged += OnHierarchyChanged;
        }

        private void OnDisable()
        {
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
        }

        private void BindUI(VisualElement root)
        {
            _avatarField     = root.Q<ObjectField>("avatar-field");
            _refreshBtn      = root.Q<Button>("refresh-btn");
            _losslessBtn     = root.Q<Button>("lossless-btn");
            _viewGoBtn       = root.Q<Button>("view-go-btn");
            _viewAssetBtn    = root.Q<Button>("view-asset-btn");
            _sortField       = root.Q<EnumField>("sort-mode");
            _hideToggle      = root.Q<Toggle>("hide-small-toggle");
            _maSimToggle     = root.Q<Toggle>("ma-sim-toggle");
            _lastRefreshLabel= root.Q<Label>("last-refresh-label");
            _changesBadge    = root.Q<Label>("changes-badge");
            _maStatusBadge   = root.Q<Label>("ma-status-badge");
            _realStatusBadge = root.Q<Label>("real-status-badge");
            _totalLabel      = root.Q<Label>("total-label");
            _treeRoot        = root.Q<VisualElement>("tree-root");
            _optimizeTarget  = root.Q<Label>("optimize-target");
            _optimizeActions = root.Q<VisualElement>("optimize-actions");

            if (_avatarField != null)
            {
                _avatarField.objectType = typeof(GameObject);
                _avatarField.allowSceneObjects = true;
            }
            if (_sortField != null)
            {
                _sortField.Init(_sortMode);
            }
            if (_changesBadge != null)
            {
                _changesBadge.style.display = DisplayStyle.None;
            }
            if (_maStatusBadge != null)
            {
                _maStatusBadge.style.display = DisplayStyle.None;
            }
            if (_maSimToggle != null)
            {
                _maSimToggle.value = _simulateMA;
                _maSimToggle.SetEnabled(Util.MABuildSimulator.IsAvailable);
                if (!Util.MABuildSimulator.IsAvailable)
                {
                    _maSimToggle.tooltip = "Modular Avatar / NDMF not detected.";
                }
            }
            if (_realStatusBadge != null)
            {
                _realStatusBadge.style.display = DisplayStyle.None;
            }
        }

        private void RegisterEvents()
        {
            if (_refreshBtn != null) _refreshBtn.clicked += DoRefresh;
            if (_losslessBtn != null) _losslessBtn.clicked += DoLosslessOptimize;
            if (_viewGoBtn != null)
                _viewGoBtn.clicked += () => SetViewMode(BreakdownViewMode.GameObject);
            if (_viewAssetBtn != null)
                _viewAssetBtn.clicked += () => SetViewMode(BreakdownViewMode.Asset);
            if (_sortField != null)
            {
                _sortField.RegisterValueChangedCallback(evt =>
                {
                    _sortMode = (BreakdownSortMode)evt.newValue;
                    RebuildTree();
                });
            }
            if (_hideToggle != null)
            {
                _hideToggle.RegisterValueChangedCallback(evt =>
                {
                    _hideSmall = evt.newValue;
                    RebuildTree();
                });
            }
            if (_avatarField != null)
            {
                _avatarField.RegisterValueChangedCallback(evt =>
                {
                    _avatar = evt.newValue as GameObject;
                });
            }
            if (_maSimToggle != null)
            {
                _maSimToggle.RegisterValueChangedCallback(evt =>
                {
                    _simulateMA = evt.newValue;
                });
            }
        }

        private void TryAutoBindAvatar()
        {
#if AVATARSCOPE_HAS_VRCSDK
            // Prefer the avatar in current selection.
            if (Selection.activeGameObject != null)
            {
                var sel = Selection.activeGameObject;
                var desc = sel.GetComponentInParent<VRCAvatarDescriptor>();
                if (desc != null)
                {
                    _avatar = desc.gameObject;
                    if (_avatarField != null) _avatarField.value = _avatar;
                    return;
                }
            }

            // Otherwise pick the first VRCAvatarDescriptor in the open scenes.
            var all = UnityEngine.Object.FindObjectsOfType<VRCAvatarDescriptor>();
            if (all != null && all.Length > 0)
            {
                _avatar = all[0].gameObject;
                if (_avatarField != null) _avatarField.value = _avatar;
            }
#endif
        }

        private void OnHierarchyChanged()
        {
            if (_result == null) return;
            _changesSinceRefresh++;
            if (_changesBadge != null)
            {
                _changesBadge.text = $"⚠ {_changesSinceRefresh} changes pending";
                _changesBadge.style.display = DisplayStyle.Flex;
            }
        }

        private void SetViewMode(BreakdownViewMode mode)
        {
            _viewMode = mode;
            if (_viewGoBtn != null)    _viewGoBtn.EnableInClassList("active",    mode == BreakdownViewMode.GameObject);
            if (_viewAssetBtn != null) _viewAssetBtn.EnableInClassList("active", mode == BreakdownViewMode.Asset);
            RebuildTree();
        }

        private void DoRefresh()
        {
            if (_avatar == null)
            {
                ShowMessage("Avatar not set. Drag a VRCAvatarDescriptor GameObject into the field above.");
                return;
            }

            try
            {
                _result = MetricsCollector.Collect(_avatar, _simulateMA, _measureRealSize);
                _lastRefresh = DateTime.Now;
                _changesSinceRefresh = 0;
                if (_changesBadge != null) _changesBadge.style.display = DisplayStyle.None;
                UpdateMAStatusBadge();
                UpdateRealStatusBadge();
                RenderResult();
            }
            catch (Exception e)
            {
                Debug.LogError($"[AvatarScope] Refresh failed: {e}");
                ShowMessage($"Refresh failed: {e.Message}");
            }
        }

        private void DoLosslessOptimize()
        {
            if (_avatar == null)
            {
                EditorUtility.DisplayDialog("AvatarScope", "Avatar not set.", "OK");
                return;
            }

            bool ok = EditorUtility.DisplayDialog(
                "Visual Lossless Optimizer",
                "アバターを 4 方向から撮影し、各非破壊最適化を試行して " +
                "見た目に劣化が出ない範囲で適用します。\n\n" +
                "・元のアセットファイルは変更されません（インポート設定のみ変更）\n" +
                "・劣化検出時は自動でロールバック\n" +
                "・所要時間: アセット数次第で 30 秒〜数分\n\n" +
                "実行しますか？",
                "実行する",
                "キャンセル");
            if (!ok) return;

            // Stage 1: collect candidates (fast, no asset changes).
            var candidates = LosslessOptimizer.PrepareCandidates(_avatar);
            if (candidates == null || candidates.Count == 0)
            {
                EditorUtility.DisplayDialog(
                    "AvatarScope",
                    "適用可能な最適化候補が見つかりませんでした。\n既に最適化済みかもしれません。",
                    "OK");
                return;
            }
            // Stage 2: show preview window. User picks, hits Apply, the window itself
            // calls LosslessOptimizer.RunSelected and opens the result window.
            OptimizePreviewWindow.Show(_avatar, candidates);
        }

        private void ShowMessage(string msg)
        {
            if (_treeRoot == null) return;
            _treeRoot.Clear();
            var l = new Label(msg);
            l.AddToClassList("placeholder");
            _treeRoot.Add(l);
        }

        private void ClearResultDisplay()
        {
            if (_lastRefreshLabel != null) _lastRefreshLabel.text = "Last refresh: never";
            if (_totalLabel != null) _totalLabel.text = "Total: —";
        }

        private void UpdateOptimizePanel(UnityEngine.Object asset)
        {
            _selectedAsset = asset;
            if (_optimizeActions == null || _optimizeTarget == null) return;

            _optimizeActions.Clear();

            if (asset == null)
            {
                _optimizeTarget.text = "(no asset selected)";
                return;
            }

            string path = AssetDatabase.GetAssetPath(asset);
            string typeName = asset.GetType().Name;
            _optimizeTarget.text = !string.IsNullOrEmpty(path)
                ? $"{asset.name}  ·  {typeName}  ·  {System.IO.Path.GetFileName(path)}"
                : $"{asset.name}  ·  {typeName}";

            var actions = OptimizeActions.GetFor(asset);
            if (actions.Count == 0)
            {
                var hint = new Label("No automatic optimizations available for this asset type.");
                hint.AddToClassList("optimize-target");
                _optimizeActions.Add(hint);
                return;
            }

            foreach (var action in actions)
            {
                var btn = new Button(() =>
                {
                    try
                    {
                        action.Execute?.Invoke();
                        // Refresh the panel so applied options disappear / new options appear.
                        UpdateOptimizePanel(_selectedAsset);
                        // Also refresh the metrics so the user sees the impact immediately.
                        if (_avatar != null)
                        {
                            _result = MetricsCollector.Collect(_avatar, _simulateMA);
                            _lastRefresh = System.DateTime.Now;
                            _changesSinceRefresh = 0;
                            UpdateMAStatusBadge();
                            RenderResult();
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogError($"[AvatarScope] Optimize failed: {ex}");
                    }
                })
                { text = action.Label };
                btn.tooltip = action.Tooltip ?? "";
                btn.AddToClassList("optimize-btn");
                _optimizeActions.Add(btn);
            }
        }

        private void UpdateMAStatusBadge()
        {
            if (_maStatusBadge == null || _result == null) return;
            if (_result.MASimulationActive)
            {
                _maStatusBadge.text = "MA build simulated";
                _maStatusBadge.style.display = DisplayStyle.Flex;
            }
            else
            {
                _maStatusBadge.style.display = DisplayStyle.None;
            }
        }

        private void UpdateRealStatusBadge()
        {
            if (_realStatusBadge == null || _result == null) return;
            if (_result.RealDownloadBytesPC.HasValue)
            {
                bool isExact = !string.IsNullOrEmpty(_result.RealMeasurementMethod)
                                && _result.RealMeasurementMethod.StartsWith("VRC SDK exact");
                _realStatusBadge.text = isExact
                    ? $"VRC Exact {_result.RealMeasurementSeconds:F1}s"
                    : $"Real build {_result.RealMeasurementSeconds:F1}s";
                _realStatusBadge.style.display = DisplayStyle.Flex;
                _realStatusBadge.tooltip = isExact
                    ? $"Used VRChat SDK build pipeline — matches uploaded size exactly.\nMethod: {_result.RealMeasurementMethod}"
                    : $"Used Unity BuildPipeline — typically ±1-5% of VRChat reported size.\nMethod: {_result.RealMeasurementMethod}";
            }
            else if (!string.IsNullOrEmpty(_result.RealMeasurementError))
            {
                _realStatusBadge.text = "Real build failed";
                _realStatusBadge.tooltip = _result.RealMeasurementError;
                _realStatusBadge.style.display = DisplayStyle.Flex;
            }
            else
            {
                _realStatusBadge.style.display = DisplayStyle.None;
            }
        }

        // ----- Render -----

        private void RenderResult()
        {
            if (_result == null) return;

            if (_lastRefreshLabel != null)
                _lastRefreshLabel.text = $"Last refresh: {_lastRefresh:HH:mm:ss}";

            RebuildTree();
            RenderSummary();
        }

        private void RebuildTree()
        {
            if (_treeRoot == null || _result == null) return;
            _treeRoot.Clear();

            var list = _viewMode == BreakdownViewMode.GameObject
                ? _result.BreakdownGameObject
                : _result.BreakdownAsset;
            if (list == null || list.Count == 0)
            {
                ShowMessage("No items found in selected view.");
                if (_totalLabel != null) _totalLabel.text = "Total: 0 B";
                return;
            }

            BreakdownBuilder.Sort(list, _sortMode);

            long total = 0;
            foreach (var it in list) total += GetSortValue(it, _sortMode);

            if (_totalLabel != null)
                _totalLabel.text = $"Total: {FormatSortValue(total, _sortMode)}";

            int hiddenCount = 0;
            long hiddenSum = 0;
            foreach (var it in list)
            {
                double pct = total > 0 ? (double)GetSortValue(it, _sortMode) / total * 100.0 : 0;
                if (_hideSmall && pct < 1.0)
                {
                    hiddenCount++;
                    hiddenSum += GetSortValue(it, _sortMode);
                    continue;
                }
                _treeRoot.Add(BuildRow(it, total, 0));
            }

            if (hiddenCount > 0)
            {
                var summaryRow = new Label($"... {hiddenCount} items hidden (< 1%)");
                summaryRow.AddToClassList("placeholder");
                summaryRow.style.paddingTop = 4;
                summaryRow.style.paddingBottom = 4;
                _treeRoot.Add(summaryRow);
            }
        }

        private VisualElement BuildRow(BreakdownItem item, long total, int depth)
        {
            var row = new VisualElement();
            row.AddToClassList("tree-row");
            if (depth > 0) row.AddToClassList($"indent-{Math.Min(depth, 3)}");

            // Foldout indicator
            bool hasChildren = item.Children != null && item.Children.Count > 0;
            var fold = new Label(hasChildren ? "▶" : "·");
            fold.AddToClassList("tree-foldout");
            row.Add(fold);

            var name = new Label(item.Name);
            name.AddToClassList("tree-name");
            row.Add(name);

            // Bar
            long val = GetSortValue(item, _sortMode);
            double pct = total > 0 ? (double)val / total * 100.0 : 0;
            var status = ColorThresholds.FromPercent(pct);

            var bar = new VisualElement();
            bar.AddToClassList("tree-bar");
            var barFill = new VisualElement();
            barFill.AddToClassList("tree-bar-fill");
            barFill.AddToClassList(ColorThresholds.ToBarClass(status));
            barFill.style.width = Length.Percent((float)Math.Min(100, pct));
            bar.Add(barFill);
            row.Add(bar);

            var valueLabel = new Label(FormatSortValue(val, _sortMode));
            valueLabel.AddToClassList("tree-value");
            valueLabel.AddToClassList(ColorThresholds.ToUssClass(status));
            row.Add(valueLabel);

            var pctLabel = new Label($"{pct:F1}%");
            pctLabel.AddToClassList("tree-percent");
            pctLabel.AddToClassList(ColorThresholds.ToUssClass(status));
            row.Add(pctLabel);

            // Click to ping/select the underlying object and update the optimize panel.
            row.RegisterCallback<ClickEvent>(_ =>
            {
                if (item.UnityObject != null)
                {
                    EditorGUIUtility.PingObject(item.UnityObject);
                    Selection.activeObject = item.UnityObject;
                    UpdateOptimizePanel(item.UnityObject);
                }
            });

            var container = new VisualElement();
            container.Add(row);

            if (hasChildren)
            {
                // Lazy-expand: simple always-expanded for now.
                foreach (var c in item.Children)
                {
                    container.Add(BuildRow(c, total, depth + 1));
                }
            }

            return container;
        }

        private static long GetSortValue(BreakdownItem item, BreakdownSortMode mode)
        {
            switch (mode)
            {
                case BreakdownSortMode.FileSize:  return item.FileSizeBytes;
                case BreakdownSortMode.VRAM:      return item.VRAMBytes;
                case BreakdownSortMode.Polygons:  return item.Polygons;
                case BreakdownSortMode.PhysBones: return item.PhysBones;
            }
            return 0;
        }

        private static string FormatSortValue(long val, BreakdownSortMode mode)
        {
            switch (mode)
            {
                case BreakdownSortMode.FileSize:  return ColorThresholds.FormatBytes(val);
                case BreakdownSortMode.VRAM:      return ColorThresholds.FormatBytes(val);
                case BreakdownSortMode.Polygons:  return $"{val:N0} tri";
                case BreakdownSortMode.PhysBones: return $"{val} bone";
            }
            return val.ToString();
        }

        private void RenderSummary()
        {
            var root = rootVisualElement;

            RenderSizeRows(root);
            RenderDetailRows(root);

            // Performance Rank - overall PC / Quest badges
            SetRankBadge(root, "rank-pc",    _result.RankPC);
            SetRankBadge(root, "rank-quest", _result.RankQuest);

            // Parameters
            SetMetricRow(root, "param", _result.ParamBitsUsed, _result.ParamBitsMax,
                $"{_result.ParamBitsUsed} / {_result.ParamBitsMax} bit");
            var paramDetail = root.Q<Label>("val-param-detail");
            if (paramDetail != null)
                paramDetail.text = $"Bool {_result.ParamCountBool} · Int {_result.ParamCountInt} · Float {_result.ParamCountFloat}";

            // Compatibility
            SetCompatLine(root, "compat-pc",       "PC Upload",  _result.PCUploadOK,      _result.PCUploadMessage);
            SetCompatLine(root, "compat-quest",    "Quest",      _result.QuestCompatible, _result.QuestMessage);
            SetCompatLine(root, "compat-fallback", "Fallback",   _result.FallbackEligible,_result.FallbackMessage);
            SetCompatLine(root, "compat-facetra",  "Facetra",    _result.FacetraReady,    _result.FacetraMessage);
        }

        private void RenderSizeRows(VisualElement root)
        {
            var container = root.Q<VisualElement>("size-rows");
            if (container == null) return;
            container.Clear();

            bool hasReal = _result.RealDownloadBytesPC.HasValue;

            // ダウンロードサイズ: when real measurement available, show real instead of estimate.
            if (hasReal)
            {
                long real = _result.RealDownloadBytesPC.Value;
                bool isExact = !string.IsNullOrEmpty(_result.RealMeasurementMethod)
                                && _result.RealMeasurementMethod.StartsWith("VRC SDK exact");
                string label = isExact
                    ? "ダウンロードサイズ (VRC SDK 完全一致)"
                    : "ダウンロードサイズ (実測)";
                AddSizeRow(container, label,
                    ColorThresholds.FormatBytes(real),
                    real, DownloadBudgetBytes);
            }
            else
            {
                AddSizeRow(container, "ダウンロードサイズ (推定)",
                    ColorThresholds.FormatBytes(_result.DownloadEstimateBytes),
                    _result.DownloadEstimateBytes, DownloadBudgetBytes);
            }

            // テクスチャメモリー (VRAM)
            AddSizeRow(container, "テクスチャメモリー",
                ColorThresholds.FormatBytes(_result.VRAMEstimateBytes),
                _result.VRAMEstimateBytes, VRAMBudgetBytes);

            // 非圧縮サイズ
            long uncompressed = _result.UncompressedBytes > 0
                ? _result.UncompressedBytes
                : _result.UploadEstimateBytes * 3; // fallback heuristic
            AddSizeRow(container, "非圧縮サイズ",
                ColorThresholds.FormatBytes(uncompressed),
                uncompressed, DownloadBudgetBytes * 5);
        }

        private void AddSizeRow(VisualElement container, string label, string valueText, long value, long budget)
        {
            var row = new VisualElement();
            row.AddToClassList("metric-row");

            var l = new Label(label);
            l.AddToClassList("metric-label");
            l.style.width = 220;
            row.Add(l);

            var bar = new VisualElement();
            bar.AddToClassList("bar");
            var ratio = budget > 0 ? (double)value / budget : 0;
            var status = ColorThresholds.FromUsageRatio(ratio);
            var fill = new VisualElement();
            fill.AddToClassList("bar-fill");
            fill.AddToClassList(ColorThresholds.ToBarClass(status));
            fill.style.width = Length.Percent((float)Math.Min(100, ratio * 100));
            bar.Add(fill);
            row.Add(bar);

            var v = new Label(valueText);
            v.AddToClassList("metric-value");
            v.AddToClassList(ColorThresholds.ToUssClass(status));
            row.Add(v);

            container.Add(row);
        }

        // ---- VRChat Avatar Detail rows ----

        private static readonly (string label, string category, System.Func<MetricsResult, string> value)[] DetailEntries =
        {
            ("三角ポリゴンの数",           "PolyCount",                  r => $"{r.Polygons:N0} / 70,000"),
            ("範囲 (BOUNDS)",              null,                         r => FormatBounds(r.BoundsSize)),
            ("スキンドメッシュの数",       "SkinnedMeshCount",           r => $"{r.SkinnedMeshes} / 16"),
            ("基本メッシュの数",           "MeshCount",                  r => $"{r.Meshes} / 24"),
            ("マテリアルスロットの数",     "MaterialCount",              r => $"{r.Materials} / 32"),
            ("PHYSBONE コンポーネントの数","PhysBoneComponentCount",     r => $"{r.PhysBones} / 32"),
            ("PHYSBONE トランスフォームの数","PhysBoneTransformCount",   r => $"{r.PhysBoneTransforms} / 256"),
            ("PHYSBONE コライダーの数",    "PhysBoneColliderCount",      r => $"{r.Colliders} / 32"),
            ("PHYSBONE 衝突チェックの数",  "PhysBoneCollisionCheckCount",r => $"{r.PhysBoneCollisionChecks} / 512"),
            ("コンタクトの数",             "ContactCount",               r => $"{r.Contacts} / 32"),
            ("コンストレイントの数",       "ConstraintCount",            r => $"{r.Constraints} / 350"),
            ("コンストレイントの深さ",     "ConstraintDepth",            r => $"{r.ConstraintDepth} / 100"),
            ("アニメーターの数",           "AnimatorCount",              r => $"{r.Animators} / 32"),
            ("ボーンの数",                 "BoneCount",                  r => $"{r.Bones} / 400"),
            ("ライトの数",                 "LightCount",                 r => $"{r.Lights} / 1"),
            ("パーティクルシステムの数",   "ParticleSystemCount",        r => $"{r.ParticleSystems} / 16"),
            ("最大パーティクルの数",       "ParticleTotalCount",         r => $"{r.ParticleMaxTotal} / 2,500"),
            ("メッシュパーティクルの三角ポリゴン数","ParticleMeshPolyCount", r => $"{r.ParticleMeshPolygons} / 5,000"),
            ("パーティクルトレイル",       "ParticleTrails",             r => $"{(r.ParticleTrails?"あり":"なし")}"),
            ("パーティクルの衝突",         "ParticleCollision",          r => $"{(r.ParticleCollision?"あり":"なし")}"),
            ("トレイルレンダラーの数",     "TrailRendererCount",         r => $"{r.TrailRenderers} / 8"),
            ("CLOTH メッシュの数",         "ClothCount",                 r => $"{r.ClothMeshes} / 1"),
            ("CLOTH の最大頂点の数",       "ClothMaxVertices",           r => $"{r.ClothMaxVertices} / 200"),
            ("コライダーの数",             "PhysicsColliderCount",       r => $"{r.PhysicsColliders} / 8"),
            ("リジッドボディの数",         "PhysicsRigidbodyCount",      r => $"{r.PhysicsRigidbodies} / 8"),
            ("オーディオソースの数",       "AudioSourceCount",           r => $"{r.AudioSources} / 16"),
        };

        private void RenderDetailRows(VisualElement root)
        {
            var container = root.Q<VisualElement>("detail-rows");
            if (container == null) return;
            container.Clear();

            foreach (var entry in DetailEntries)
            {
                var rank = entry.category != null ? RankFor(entry.category) : MetricsResult.VRCRank.None;
                AddDetailRow(container, entry.label, entry.value(_result), rank);
            }
        }

        private static void AddDetailRow(VisualElement container, string label, string value, MetricsResult.VRCRank rank)
        {
            var row = new VisualElement();
            row.AddToClassList("metric-row");

            var l = new Label(label);
            l.AddToClassList("metric-label");
            l.style.width = 220;
            row.Add(l);

            var v = new Label(value);
            v.AddToClassList("metric-value");
            v.AddToClassList(RankValueClass(rank));
            row.Add(v);

            container.Add(row);
        }

        private static string FormatBounds(Vector3? size)
        {
            if (!size.HasValue) return "—";
            var s = size.Value;
            return $"({s.x:F2}, {s.y:F2}, {s.z:F2}) / (5.00, 6.00, 5.00)";
        }

        private MetricsResult.VRCRank RankFor(string category)
        {
            if (_result == null) return MetricsResult.VRCRank.None;
            // Prefer PC ranks for display, since it's the more lenient platform — if PC is bad, Quest is worse.
            if (_result.PerCategoryPC != null && _result.PerCategoryPC.TryGetValue(category, out var r))
                return r;
            return MetricsResult.VRCRank.None;
        }

        private static void SetRankBadge(VisualElement root, string id, MetricsResult.VRCRank rank)
        {
            var l = root.Q<Label>(id);
            if (l == null) return;
            l.text = RankLabel(rank);
            ClearRankClasses(l);
            l.AddToClassList(RankBadgeClass(rank));
        }

        private static void SetRankedValue(VisualElement root, string id, string text, MetricsResult.VRCRank rank)
        {
            var l = root.Q<Label>(id);
            if (l == null) return;
            l.text = text;
            ClearValueRankClasses(l);
            l.AddToClassList(RankValueClass(rank));
        }

        private static string RankLabel(MetricsResult.VRCRank r)
        {
            switch (r)
            {
                case MetricsResult.VRCRank.Excellent: return "Excellent";
                case MetricsResult.VRCRank.Good:      return "Good";
                case MetricsResult.VRCRank.Medium:    return "Medium";
                case MetricsResult.VRCRank.Poor:      return "Poor";
                case MetricsResult.VRCRank.VeryPoor:  return "Very Poor";
                default:                              return "—";
            }
        }

        private static string RankBadgeClass(MetricsResult.VRCRank r)
        {
            switch (r)
            {
                case MetricsResult.VRCRank.Excellent: return "rank-excellent";
                case MetricsResult.VRCRank.Good:      return "rank-good";
                case MetricsResult.VRCRank.Medium:    return "rank-medium";
                case MetricsResult.VRCRank.Poor:      return "rank-poor";
                case MetricsResult.VRCRank.VeryPoor:  return "rank-verypoor";
                default:                              return "rank-none";
            }
        }

        private static string RankValueClass(MetricsResult.VRCRank r)
        {
            switch (r)
            {
                case MetricsResult.VRCRank.Excellent: return "value-excellent";
                case MetricsResult.VRCRank.Good:      return "value-good";
                case MetricsResult.VRCRank.Medium:    return "value-medium";
                case MetricsResult.VRCRank.Poor:      return "value-poor";
                case MetricsResult.VRCRank.VeryPoor:  return "value-verypoor";
                default:                              return "";
            }
        }

        private static void ClearRankClasses(VisualElement v)
        {
            v.RemoveFromClassList("rank-excellent");
            v.RemoveFromClassList("rank-good");
            v.RemoveFromClassList("rank-medium");
            v.RemoveFromClassList("rank-poor");
            v.RemoveFromClassList("rank-verypoor");
            v.RemoveFromClassList("rank-none");
        }

        private static void ClearValueRankClasses(VisualElement v)
        {
            v.RemoveFromClassList("value-excellent");
            v.RemoveFromClassList("value-good");
            v.RemoveFromClassList("value-medium");
            v.RemoveFromClassList("value-poor");
            v.RemoveFromClassList("value-verypoor");
        }

        private void SetMetricRow(VisualElement root, string id, long value, long budget, string text)
        {
            var val = root.Q<Label>($"val-{id}");
            var bar = root.Q<VisualElement>($"bar-{id}");
            if (val == null) return;

            var ratio = budget > 0 ? (double)value / budget : 0;
            var status = ColorThresholds.FromUsageRatio(ratio);

            val.text = text;
            ClearStatusClasses(val);
            val.AddToClassList(ColorThresholds.ToUssClass(status));

            if (bar != null)
            {
                bar.Clear();
                var fill = new VisualElement();
                fill.AddToClassList("bar-fill");
                fill.AddToClassList(ColorThresholds.ToBarClass(status));
                fill.style.width = Length.Percent((float)Math.Min(100, ratio * 100));
                bar.Add(fill);
            }
        }

        private static void ClearStatusClasses(VisualElement v)
        {
            v.RemoveFromClassList("status-safe");
            v.RemoveFromClassList("status-caution");
            v.RemoveFromClassList("status-heavy");
            v.RemoveFromClassList("status-critical");
        }

        private void SetCompatLine(VisualElement root, string id, string title, bool ok, string msg)
        {
            var l = root.Q<Label>(id);
            if (l == null) return;
            l.RemoveFromClassList("compat-ok");
            l.RemoveFromClassList("compat-warn");
            l.RemoveFromClassList("compat-error");

            string mark;
            if (ok) { l.AddToClassList("compat-ok"); mark = "OK"; }
            else { l.AddToClassList("compat-warn"); mark = "NG"; }
            l.text = $"[{mark}] {title}: {msg}";
        }

        // ----- Asset loading -----

        private static T LoadAsset<T>(string nameQuery, string extension) where T : UnityEngine.Object
        {
            // Find by filter inside this package.
            var guids = AssetDatabase.FindAssets($"{nameQuery} t:{typeof(T).Name}");
            foreach (var g in guids)
            {
                var p = AssetDatabase.GUIDToAssetPath(g);
                if (p.EndsWith("." + extension, StringComparison.OrdinalIgnoreCase))
                {
                    var t = AssetDatabase.LoadAssetAtPath<T>(p);
                    if (t != null) return t;
                }
            }
            return null;
        }
    }
}

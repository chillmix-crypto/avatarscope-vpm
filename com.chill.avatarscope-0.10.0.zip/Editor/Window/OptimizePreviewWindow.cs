using System;
using System.Collections.Generic;
using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Chill.AvatarScope.Editor.Window
{
    /// <summary>
    /// Shows a checkbox list of every optimization candidate before applying.
    /// Users can deselect risky operations or whole categories. Applying triggers
    /// LosslessOptimizer.RunSelected and then opens OptimizeResultWindow.
    /// </summary>
    public class OptimizePreviewWindow : EditorWindow
    {
        private GameObject _avatar;
        private List<IOptCandidate> _candidates;
        private ScrollView _list;
        private Label _summary;

        public static void Show(GameObject avatar, List<IOptCandidate> candidates)
        {
            var w = CreateInstance<OptimizePreviewWindow>();
            w.titleContent = new GUIContent("AvatarScope - Optimize Preview");
            w._avatar = avatar;
            w._candidates = candidates;
            w.minSize = new Vector2(720, 480);
            w.Show();
        }

        public void CreateGUI()
        {
            var root = rootVisualElement;
            root.style.backgroundColor = new StyleColor(new Color(0.22f, 0.22f, 0.22f));

            // Header
            var hdr = new VisualElement();
            hdr.style.paddingTop = 8;
            hdr.style.paddingBottom = 6;
            hdr.style.paddingLeft = 10;
            hdr.style.paddingRight = 10;
            hdr.style.backgroundColor = new StyleColor(new Color(0.28f, 0.28f, 0.28f));

            var title = new Label("最適化候補一覧 (Visual Lossless)");
            title.style.fontSize = 14;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.color = new StyleColor(new Color(0.95f, 0.95f, 0.95f));
            hdr.Add(title);

            _summary = new Label("");
            _summary.style.color = new StyleColor(new Color(0.65f, 0.9f, 0.7f));
            _summary.style.marginTop = 2;
            hdr.Add(_summary);

            var subtitle = new Label("チェックを外すと適用されません。各カテゴリの全選択/解除も可能。");
            subtitle.style.color = new StyleColor(new Color(0.75f, 0.75f, 0.75f));
            subtitle.style.fontSize = 11;
            subtitle.style.marginTop = 2;
            hdr.Add(subtitle);

            root.Add(hdr);

            // List
            _list = new ScrollView();
            _list.style.flexGrow = 1;
            _list.style.backgroundColor = new StyleColor(new Color(0.18f, 0.18f, 0.18f));
            _list.style.paddingTop = 4;
            _list.style.paddingBottom = 4;
            root.Add(_list);
            BuildList();

            // Footer buttons
            var footer = new VisualElement();
            footer.style.flexDirection = FlexDirection.Row;
            footer.style.justifyContent = Justify.FlexEnd;
            footer.style.paddingTop = 8;
            footer.style.paddingBottom = 8;
            footer.style.paddingLeft = 10;
            footer.style.paddingRight = 10;
            footer.style.backgroundColor = new StyleColor(new Color(0.25f, 0.25f, 0.25f));

            var cancel = new Button(() => Close()) { text = "キャンセル" };
            cancel.style.paddingTop = 4;
            cancel.style.paddingBottom = 4;
            cancel.style.paddingLeft = 14;
            cancel.style.paddingRight = 14;
            cancel.style.marginRight = 6;
            footer.Add(cancel);

            var apply = new Button(OnApply) { text = "選択中の操作を適用" };
            apply.style.backgroundColor = new StyleColor(new Color(0.37f, 0.5f, 0.78f));
            apply.style.color = new StyleColor(Color.white);
            apply.style.unityFontStyleAndWeight = FontStyle.Bold;
            apply.style.paddingTop = 4;
            apply.style.paddingBottom = 4;
            apply.style.paddingLeft = 18;
            apply.style.paddingRight = 18;
            footer.Add(apply);

            root.Add(footer);

            UpdateSummary();
        }

        // -- list -----

        private void BuildList()
        {
            _list.Clear();
            if (_candidates == null || _candidates.Count == 0)
            {
                var l = new Label("候補がありません。アバターは既に最適化済みかもしれません。");
                l.style.color = new StyleColor(new Color(0.6f, 0.6f, 0.6f));
                l.style.paddingTop = 24;
                l.style.unityTextAlign = TextAnchor.UpperCenter;
                _list.Add(l);
                return;
            }

            // Group by category.
            var byCategory = new Dictionary<string, List<IOptCandidate>>();
            foreach (var c in _candidates)
            {
                if (!byCategory.TryGetValue(c.Category, out var list))
                {
                    list = new List<IOptCandidate>();
                    byCategory[c.Category] = list;
                }
                list.Add(c);
            }

            foreach (var kv in byCategory)
            {
                _list.Add(BuildCategorySection(kv.Key, kv.Value));
            }
        }

        private VisualElement BuildCategorySection(string category, List<IOptCandidate> items)
        {
            long deltaDown = 0;
            long deltaVram = 0;
            foreach (var i in items) { deltaDown += i.EstimatedDownloadDelta; deltaVram += i.EstimatedVRAMDelta; }

            var fold = new Foldout
            {
                text = $"{category}  ({items.Count}件, 削減見込み {FormatDelta(deltaDown)} / VRAM {FormatDelta(deltaVram)})",
                value = true,
            };
            fold.style.unityFontStyleAndWeight = FontStyle.Bold;
            fold.style.marginTop = 4;
            fold.style.marginBottom = 2;
            fold.style.paddingLeft = 8;
            fold.style.paddingRight = 8;

            // Select all / none in category
            var head = new VisualElement();
            head.style.flexDirection = FlexDirection.Row;
            head.style.marginBottom = 2;
            var selAll = new Button(() => { foreach (var i in items) i.IsSelected = true; BuildList(); UpdateSummary(); }) { text = "全選択" };
            selAll.style.fontSize = 10;
            selAll.style.paddingLeft = 6;
            selAll.style.paddingRight = 6;
            head.Add(selAll);
            var selNone = new Button(() => { foreach (var i in items) i.IsSelected = false; BuildList(); UpdateSummary(); }) { text = "全解除" };
            selNone.style.fontSize = 10;
            selNone.style.paddingLeft = 6;
            selNone.style.paddingRight = 6;
            head.Add(selNone);
            fold.Add(head);

            foreach (var it in items)
            {
                fold.Add(BuildRow(it));
            }
            return fold;
        }

        private VisualElement BuildRow(IOptCandidate cand)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.paddingTop = 1;
            row.style.paddingBottom = 1;
            row.style.paddingLeft = 16;
            row.style.unityFontStyleAndWeight = FontStyle.Normal;

            var tog = new Toggle { value = cand.IsSelected };
            tog.RegisterValueChangedCallback(evt => { cand.IsSelected = evt.newValue; UpdateSummary(); });
            tog.style.marginRight = 4;
            row.Add(tog);

            var label = new Label(cand.Label);
            label.style.flexGrow = 1;
            label.style.color = new StyleColor(new Color(0.88f, 0.88f, 0.88f));
            row.Add(label);

            if (cand.RequiresVerification)
            {
                var verify = new Label("[要視覚検証]");
                verify.style.color = new StyleColor(new Color(0.6f, 0.8f, 1f));
                verify.style.fontSize = 10;
                verify.style.marginRight = 6;
                row.Add(verify);
            }

            var delta = new Label(FormatDelta(cand.EstimatedDownloadDelta));
            delta.style.color = new StyleColor(cand.EstimatedDownloadDelta < 0 ? new Color(0.55f, 0.85f, 0.6f) : new Color(0.7f, 0.7f, 0.7f));
            delta.style.minWidth = 90;
            delta.style.unityTextAlign = TextAnchor.MiddleRight;
            row.Add(delta);

            // Click row to ping
            row.RegisterCallback<MouseDownEvent>(e =>
            {
                if (e.button == 0 && cand.TargetAsset != null)
                {
                    EditorGUIUtility.PingObject(cand.TargetAsset);
                }
            });

            return row;
        }

        private void UpdateSummary()
        {
            if (_summary == null) return;
            int selected = 0;
            long down = 0, vram = 0;
            foreach (var c in _candidates)
            {
                if (!c.IsSelected) continue;
                selected++;
                down += c.EstimatedDownloadDelta;
                vram += c.EstimatedVRAMDelta;
            }
            _summary.text = $"選択中 {selected} / {_candidates.Count}  ·  削減見込み Download {FormatDelta(down)} / VRAM {FormatDelta(vram)}";
        }

        private static string FormatDelta(long bytes)
        {
            if (bytes == 0) return "  0";
            string s = bytes < 0 ? "-" : "+";
            return s + ColorThresholds.FormatBytes(System.Math.Abs(bytes));
        }

        private void OnApply()
        {
            if (_avatar == null)
            {
                Close();
                return;
            }
            var report = LosslessOptimizer.RunSelected(_avatar, _candidates);
            Close();

            if (!string.IsNullOrEmpty(report.ErrorMessage))
            {
                EditorUtility.DisplayDialog("AvatarScope", $"Error: {report.ErrorMessage}", "OK");
                return;
            }
            OptimizeResultWindow.Show(report);
        }
    }
}

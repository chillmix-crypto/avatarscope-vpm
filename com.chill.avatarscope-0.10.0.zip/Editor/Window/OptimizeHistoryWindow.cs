using System;
using System.IO;
using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Chill.AvatarScope.Editor.Window
{
    /// <summary>
    /// Lists every optimization ever applied through AvatarScope, newest first.
    /// Each row has an Undo button that calls back into the original op's Revert path.
    /// </summary>
    public class OptimizeHistoryWindow : EditorWindow
    {
        private ScrollView _list;

        [MenuItem("Tools/AvatarScope/Optimization History", false, 110)]
        public static void Open()
        {
            var w = GetWindow<OptimizeHistoryWindow>();
            w.titleContent = new GUIContent("AvatarScope - History");
            w.minSize = new Vector2(640, 400);
            w.Show();
        }

        public void CreateGUI()
        {
            var root = rootVisualElement;
            root.style.backgroundColor = new StyleColor(new Color(0.22f, 0.22f, 0.22f));

            // Header
            var hdr = new VisualElement();
            hdr.style.paddingTop = 8;
            hdr.style.paddingBottom = 6;
            hdr.style.paddingLeft = 10;
            hdr.style.paddingRight = 10;
            hdr.style.backgroundColor = new StyleColor(new Color(0.28f, 0.28f, 0.28f));
            hdr.style.flexDirection = FlexDirection.Row;
            hdr.style.alignItems = Align.Center;

            var title = new Label("最適化履歴");
            title.style.fontSize = 14;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.color = new StyleColor(new Color(0.95f, 0.95f, 0.95f));
            title.style.flexGrow = 1;
            hdr.Add(title);

            var refresh = new Button(BuildList) { text = "更新" };
            refresh.style.marginRight = 4;
            hdr.Add(refresh);

            var clear = new Button(OnClear) { text = "履歴を消去" };
            hdr.Add(clear);

            root.Add(hdr);

            _list = new ScrollView();
            _list.style.flexGrow = 1;
            root.Add(_list);

            BuildList();
        }

        private void BuildList()
        {
            if (_list == null) return;
            _list.Clear();

            var doc = OptHistory.Load();
            if (doc.Entries.Count == 0)
            {
                var l = new Label("履歴はまだありません。Optimize (Lossless) を実行すると蓄積されます。");
                l.style.color = new StyleColor(new Color(0.6f, 0.6f, 0.6f));
                l.style.paddingTop = 28;
                l.style.unityTextAlign = TextAnchor.UpperCenter;
                _list.Add(l);
                return;
            }

            // Newest first
            for (int i = doc.Entries.Count - 1; i >= 0; i--)
            {
                _list.Add(BuildRow(doc.Entries[i]));
            }
        }

        private VisualElement BuildRow(OptHistoryEntry e)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.alignItems = Align.Center;
            row.style.paddingTop = 4;
            row.style.paddingBottom = 4;
            row.style.paddingLeft = 8;
            row.style.paddingRight = 8;
            row.style.borderBottomWidth = 1;
            row.style.borderBottomColor = new StyleColor(new Color(0.16f, 0.16f, 0.16f));
            if (e.Reverted)
            {
                row.style.opacity = 0.4f;
            }

            var ts = new DateTime(e.TimestampUtc, DateTimeKind.Utc).ToLocalTime();
            var time = new Label(ts.ToString("MM/dd HH:mm"));
            time.style.minWidth = 70;
            time.style.color = new StyleColor(new Color(0.65f, 0.65f, 0.65f));
            time.style.fontSize = 10;
            row.Add(time);

            var avatarName = new Label(e.AvatarName ?? "");
            avatarName.style.minWidth = 100;
            avatarName.style.color = new StyleColor(new Color(0.7f, 0.85f, 1f));
            avatarName.style.fontSize = 11;
            row.Add(avatarName);

            var label = new Label(e.Label);
            label.style.flexGrow = 1;
            label.style.color = new StyleColor(new Color(0.9f, 0.9f, 0.9f));
            row.Add(label);

            if (e.DeltaDownloadBytes != 0)
            {
                var dl = new Label(FormatDelta(e.DeltaDownloadBytes));
                dl.style.minWidth = 80;
                dl.style.unityTextAlign = TextAnchor.MiddleRight;
                dl.style.color = new StyleColor(e.DeltaDownloadBytes < 0 ? new Color(0.55f, 0.85f, 0.6f) : new Color(0.7f, 0.7f, 0.7f));
                row.Add(dl);
            }

            row.RegisterCallback<MouseDownEvent>(ev =>
            {
                if (ev.button == 0 && !string.IsNullOrEmpty(e.AssetPath))
                {
                    var obj = AssetDatabase.LoadMainAssetAtPath(e.AssetPath);
                    if (obj != null) EditorGUIUtility.PingObject(obj);
                }
            });

            if (e.Reverted)
            {
                var rl = new Label("[復元済]");
                rl.style.color = new StyleColor(new Color(0.65f, 0.65f, 0.65f));
                rl.style.fontSize = 10;
                rl.style.minWidth = 60;
                row.Add(rl);
            }
            else
            {
                var undo = new Button(() =>
                {
                    if (EditorUtility.DisplayDialog("AvatarScope", $"この操作を元に戻しますか？\n\n{e.Label}", "戻す", "キャンセル"))
                    {
                        if (OptHistory.Revert(e.Id))
                        {
                            BuildList();
                            AssetDatabase.Refresh();
                        }
                        else
                        {
                            EditorUtility.DisplayDialog("AvatarScope", "元に戻せませんでした。アセットが移動・削除された可能性があります。", "OK");
                        }
                    }
                }) { text = "Undo" };
                undo.style.minWidth = 60;
                row.Add(undo);
            }

            return row;
        }

        private void OnClear()
        {
            if (EditorUtility.DisplayDialog("AvatarScope",
                "履歴を全消去します。\nUndo はできなくなりますがアセットの状態はそのままです。\n続行しますか？",
                "消去", "キャンセル"))
            {
                OptHistory.Clear();
                BuildList();
            }
        }

        private static string FormatDelta(long bytes)
        {
            if (bytes == 0) return "  0";
            string s = bytes < 0 ? "-" : "+";
            return s + ColorThresholds.FormatBytes(Math.Abs(bytes));
        }
    }
}

using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace Chill.AvatarScope.Editor.Window
{
    /// <summary>
    /// Shows the Before/After snapshots from a Visual Lossless Optimization run.
    /// Displays 4 angles side-by-side so users (and viewers of teaching streams)
    /// can verify the optimization caused no visible change.
    /// </summary>
    public class OptimizeResultWindow : EditorWindow
    {
        private static readonly string[] AngleLabels = { "Front", "Back", "Left", "Right" };

        private Texture2D[] _before;
        private Texture2D[] _after;
        private LosslessOptimizer.Report _report;

        public static void Show(LosslessOptimizer.Report report)
        {
            if (report == null) return;
            var w = CreateInstance<OptimizeResultWindow>();
            w.titleContent = new GUIContent("AvatarScope - Lossless Result");
            w._report = report;
            w._before = report.BeforeSnapshots;
            w._after = report.AfterSnapshots;
            // The window now owns the textures.
            report.BeforeSnapshots = null;
            report.AfterSnapshots = null;
            w.minSize = new Vector2(880, 620);
            w.ShowUtility();
        }

        private void OnDisable()
        {
            AvatarSnapshotter.DisposeAll(_before);
            AvatarSnapshotter.DisposeAll(_after);
            _before = null;
            _after = null;
        }

        public void CreateGUI()
        {
            var root = rootVisualElement;
            root.style.paddingTop = 10;
            root.style.paddingBottom = 10;
            root.style.paddingLeft = 10;
            root.style.paddingRight = 10;
            root.style.backgroundColor = new StyleColor(new Color(0.22f, 0.22f, 0.22f));

            BuildHeader(root);
            BuildAngleGrid(root);
            BuildLogPanel(root);
        }

        private void BuildHeader(VisualElement parent)
        {
            if (_report == null) return;
            var card = new VisualElement();
            card.style.backgroundColor = new StyleColor(new Color(0.28f, 0.28f, 0.28f));
            card.style.paddingTop = 8;
            card.style.paddingBottom = 8;
            card.style.paddingLeft = 10;
            card.style.paddingRight = 10;
            card.style.borderTopLeftRadius = card.style.borderTopRightRadius =
                card.style.borderBottomLeftRadius = card.style.borderBottomRightRadius = 4;
            card.style.marginBottom = 8;

            long saved = System.Math.Max(0, _report.SizeBeforeBytes - _report.SizeAfterBytes);
            double pct = _report.SizeBeforeBytes > 0 ? (double)saved / _report.SizeBeforeBytes * 100.0 : 0;

            var title = new Label("Visual Lossless 完了");
            title.style.fontSize = 16;
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.color = new StyleColor(new Color(0.95f, 0.95f, 0.95f));
            card.Add(title);

            var sizeRow = new Label(
                $"容量: {ColorThresholds.FormatBytes(_report.SizeBeforeBytes)} → " +
                $"{ColorThresholds.FormatBytes(_report.SizeAfterBytes)}  " +
                $"(-{ColorThresholds.FormatBytes(saved)} / -{pct:F1}%)");
            sizeRow.style.fontSize = 13;
            sizeRow.style.color = new StyleColor(new Color(0.65f, 0.9f, 0.7f));
            sizeRow.style.marginTop = 4;
            card.Add(sizeRow);

            var diffRow = new Label(
                $"視覚劣化: 平均 {_report.FinalAverageDiff:P3} / 最大 {_report.FinalWorstDiff:P3}");
            diffRow.style.fontSize = 12;
            diffRow.style.color = new StyleColor(new Color(0.8f, 0.8f, 0.8f));
            diffRow.style.marginTop = 2;
            card.Add(diffRow);

            var ops = new Label(
                $"適用 {_report.AppliedCount} / ロールバック {_report.RevertedCount} / " +
                $"スキップ {_report.SkippedCount}  ·  処理時間 {_report.DurationSeconds:F1}s");
            ops.style.fontSize = 11;
            ops.style.color = new StyleColor(new Color(0.7f, 0.7f, 0.7f));
            ops.style.marginTop = 2;
            card.Add(ops);

            parent.Add(card);
        }

        private void BuildAngleGrid(VisualElement parent)
        {
            var grid = new VisualElement();
            grid.style.flexDirection = FlexDirection.Row;
            grid.style.flexWrap = Wrap.Wrap;
            grid.style.justifyContent = Justify.SpaceAround;
            grid.style.marginBottom = 8;

            int n = _before != null ? _before.Length : 0;
            for (int i = 0; i < n; i++)
            {
                grid.Add(BuildAngleCard(AngleLabels[i % AngleLabels.Length], _before[i], _after?[i]));
            }
            parent.Add(grid);
        }

        private VisualElement BuildAngleCard(string label, Texture2D before, Texture2D after)
        {
            var card = new VisualElement();
            card.style.flexDirection = FlexDirection.Column;
            card.style.alignItems = Align.Center;
            card.style.marginBottom = 10;
            card.style.marginLeft = 4;
            card.style.marginRight = 4;

            var title = new Label(label);
            title.style.color = new StyleColor(new Color(0.9f, 0.9f, 0.9f));
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            title.style.marginBottom = 4;
            card.Add(title);

            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.Add(BuildLabeledImage("Before", before));
            row.Add(BuildLabeledImage("After",  after));
            card.Add(row);
            return card;
        }

        private VisualElement BuildLabeledImage(string label, Texture2D texture)
        {
            var col = new VisualElement();
            col.style.alignItems = Align.Center;
            col.style.marginLeft = 4;
            col.style.marginRight = 4;

            var caption = new Label(label);
            caption.style.color = new StyleColor(new Color(0.7f, 0.7f, 0.7f));
            caption.style.fontSize = 11;
            col.Add(caption);

            var img = new Image();
            img.style.width = 180;
            img.style.height = 180;
            img.style.backgroundColor = new StyleColor(new Color(0.15f, 0.15f, 0.15f));
            img.style.borderLeftWidth = img.style.borderRightWidth =
                img.style.borderTopWidth = img.style.borderBottomWidth = 1;
            img.style.borderLeftColor = img.style.borderRightColor =
                img.style.borderTopColor = img.style.borderBottomColor =
                new StyleColor(new Color(0.1f, 0.1f, 0.1f));
            if (texture != null) img.image = texture;
            col.Add(img);
            return col;
        }

        private void BuildLogPanel(VisualElement parent)
        {
            var scroll = new ScrollView();
            scroll.style.flexGrow = 1;
            scroll.style.backgroundColor = new StyleColor(new Color(0.18f, 0.18f, 0.18f));
            scroll.style.borderTopLeftRadius = scroll.style.borderTopRightRadius =
                scroll.style.borderBottomLeftRadius = scroll.style.borderBottomRightRadius = 3;
            scroll.style.paddingTop = 6;
            scroll.style.paddingBottom = 6;
            scroll.style.paddingLeft = 8;
            scroll.style.paddingRight = 8;

            AppendLogSection(scroll, "適用された操作", _report.AppliedLog,
                new Color(0.55f, 0.85f, 0.6f));
            AppendLogSection(scroll, "ロールバック (劣化検出)", _report.RevertedLog,
                new Color(0.9f, 0.6f, 0.4f));
            AppendLogSection(scroll, "スキップ", _report.SkippedLog,
                new Color(0.75f, 0.75f, 0.75f));

            parent.Add(scroll);
        }

        private static void AppendLogSection(ScrollView scroll, string title,
            System.Collections.Generic.List<string> items, Color color)
        {
            if (items == null || items.Count == 0) return;
            var header = new Label($"▼ {title} ({items.Count})");
            header.style.color = new StyleColor(color);
            header.style.unityFontStyleAndWeight = FontStyle.Bold;
            header.style.marginTop = 4;
            scroll.Add(header);

            foreach (var it in items)
            {
                var l = new Label("  · " + it);
                l.style.color = new StyleColor(new Color(0.8f, 0.8f, 0.8f));
                l.style.fontSize = 11;
                scroll.Add(l);
            }
        }
    }
}

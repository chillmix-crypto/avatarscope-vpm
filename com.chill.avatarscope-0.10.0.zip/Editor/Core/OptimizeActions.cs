using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// Non-destructive optimization actions for assets selected in the breakdown tree.
    /// All actions modify only AssetImporter settings (not the source file) and trigger Reimport.
    /// The original asset file on disk is never modified.
    /// </summary>
    public static class OptimizeActions
    {
        public class OptimizeAction
        {
            public string Label;
            public string Tooltip;
            public Action Execute;
        }

        public static List<OptimizeAction> GetFor(UnityEngine.Object asset)
        {
            var list = new List<OptimizeAction>();
            if (asset == null) return list;

            string path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) return list;

            if (asset is Texture2D)
            {
                BuildTextureActions(path, list);
            }
            else if (asset is AudioClip)
            {
                BuildAudioActions(path, list);
            }
            else if (asset is Mesh)
            {
                // Mesh optimization (decimation) is out of scope for v0.3 - delegate to AAO.
                list.Add(new OptimizeAction
                {
                    Label = "Use AAO Mesh Simplifier",
                    Tooltip = "Mesh decimation is best handled by Avatar Optimizer (AAO).",
                    Execute = () => UnityEditor.EditorUtility.DisplayDialog(
                        "AvatarScope",
                        "Mesh decimation is handled by Avatar Optimizer (AAO) — add an AAO Mesh Simplifier component on the SkinnedMeshRenderer.",
                        "OK"),
                });
            }

            return list;
        }

        // -------- Texture --------

        private static void BuildTextureActions(string path, List<OptimizeAction> list)
        {
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null) return;

            int currentMax = importer.maxTextureSize;
            int[] sizes = { 2048, 1024, 512, 256 };
            foreach (var size in sizes)
            {
                if (currentMax > size)
                {
                    int captured = size;
                    list.Add(new OptimizeAction
                    {
                        Label = $"Resize to {FormatSize(captured)}",
                        Tooltip = $"Set Max Size to {captured}px and reimport. Source file untouched.",
                        Execute = () => ApplyMaxSize(path, captured),
                    });
                }
            }

            if (!importer.crunchedCompression)
            {
                list.Add(new OptimizeAction
                {
                    Label = "Enable Crunch",
                    Tooltip = "Enable Crunch compression. Typically reduces texture download size by 50-80% with no visual change.",
                    Execute = () => ApplyCrunch(path, true, 50),
                });
            }

            if (importer.textureCompression == TextureImporterCompression.Uncompressed)
            {
                list.Add(new OptimizeAction
                {
                    Label = "Compress",
                    Tooltip = "Set Compression to Normal Quality.",
                    Execute = () => ApplyCompression(path, TextureImporterCompression.Compressed),
                });
            }

            if (importer.mipmapEnabled && currentMax >= 1024 && !IsNormalMap(importer))
            {
                list.Add(new OptimizeAction
                {
                    Label = "Disable Streaming Mipmap (small wins)",
                    Tooltip = "Disable streaming mipmaps. Minor download savings; only use if you do not need streaming.",
                    Execute = () => ApplyStreamingMipmaps(path, false),
                });
            }
        }

        private static void ApplyMaxSize(string path, int size)
        {
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) return;
            imp.maxTextureSize = size;
            imp.SaveAndReimport();
        }

        private static void ApplyCrunch(string path, bool enable, int quality)
        {
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) return;
            imp.crunchedCompression = enable;
            imp.compressionQuality = quality;
            imp.SaveAndReimport();
        }

        private static void ApplyCompression(string path, TextureImporterCompression mode)
        {
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) return;
            imp.textureCompression = mode;
            imp.SaveAndReimport();
        }

        private static void ApplyStreamingMipmaps(string path, bool enable)
        {
            var imp = AssetImporter.GetAtPath(path) as TextureImporter;
            if (imp == null) return;
            imp.streamingMipmaps = enable;
            imp.SaveAndReimport();
        }

        private static bool IsNormalMap(TextureImporter importer)
        {
            return importer.textureType == TextureImporterType.NormalMap;
        }

        private static string FormatSize(int px)
        {
            if (px >= 1024) return $"{px / 1024}K";
            return px.ToString();
        }

        // -------- Audio --------

        private static void BuildAudioActions(string path, List<OptimizeAction> list)
        {
            var importer = AssetImporter.GetAtPath(path) as AudioImporter;
            if (importer == null) return;

            var settings = importer.defaultSampleSettings;

            if (settings.compressionFormat != AudioCompressionFormat.Vorbis)
            {
                list.Add(new OptimizeAction
                {
                    Label = "Convert to Vorbis",
                    Tooltip = "Switch to Vorbis compression (good size/quality balance).",
                    Execute = () => ApplyAudioFormat(path, AudioCompressionFormat.Vorbis),
                });
            }
            // loadInBackground lives on AudioImporter itself, not on sample settings.
            if (!importer.loadInBackground)
            {
                list.Add(new OptimizeAction
                {
                    Label = "Load in Background",
                    Tooltip = "Enable async loading so the avatar appears faster.",
                    Execute = () => ApplyAudioLoadInBackground(path, true),
                });
            }
        }

        private static void ApplyAudioFormat(string path, AudioCompressionFormat fmt)
        {
            var imp = AssetImporter.GetAtPath(path) as AudioImporter;
            if (imp == null) return;
            var s = imp.defaultSampleSettings;
            s.compressionFormat = fmt;
            imp.defaultSampleSettings = s;
            imp.SaveAndReimport();
        }

        private static void ApplyAudioLoadInBackground(string path, bool enable)
        {
            var imp = AssetImporter.GetAtPath(path) as AudioImporter;
            if (imp == null) return;
            imp.loadInBackground = enable;
            imp.SaveAndReimport();
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// Persistent record of one applied optimization. Carries enough info to revert.
    /// Serialized as JSON in Library/AvatarScopeHistory.json.
    /// </summary>
    [Serializable]
    public class OptHistoryEntry
    {
        public string Id;            // unique id (guid)
        public long   TimestampUtc;  // DateTime.UtcNow.Ticks
        public string AvatarName;
        public string AssetPath;
        public string Category;      // OptCategory enum string
        public string Label;         // human readable
        public string OpKind;        // "TextureRW", "Crunch", "Resize", "MeshRW", "MeshOpt"
        public string PreviousJson;  // op-specific previous state
        public long   DeltaDownloadBytes;
        public long   DeltaVRAMBytes;
        public bool   Reverted;
    }

    [Serializable]
    public class OptHistoryDoc
    {
        public List<OptHistoryEntry> Entries = new List<OptHistoryEntry>();
    }

    public static class OptHistory
    {
        private const string FileName = "AvatarScopeHistory.json";

        private static string Path
        {
            get
            {
                string project = System.IO.Path.GetDirectoryName(Application.dataPath);
                return System.IO.Path.Combine(project, "Library", FileName);
            }
        }

        private static OptHistoryDoc _cache;

        public static OptHistoryDoc Load()
        {
            if (_cache != null) return _cache;
            try
            {
                if (File.Exists(Path))
                {
                    var json = File.ReadAllText(Path);
                    _cache = JsonUtility.FromJson<OptHistoryDoc>(json) ?? new OptHistoryDoc();
                }
                else
                {
                    _cache = new OptHistoryDoc();
                }
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AvatarScope] history load failed: {e.Message}");
                _cache = new OptHistoryDoc();
            }
            return _cache;
        }

        public static void Save()
        {
            try
            {
                var json = JsonUtility.ToJson(_cache, true);
                var dir = System.IO.Path.GetDirectoryName(Path);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(Path, json);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AvatarScope] history save failed: {e.Message}");
            }
        }

        public static void Append(OptHistoryEntry entry)
        {
            if (entry == null) return;
            if (string.IsNullOrEmpty(entry.Id)) entry.Id = Guid.NewGuid().ToString("N");
            Load().Entries.Add(entry);
            Save();
        }

        public static bool Revert(string entryId)
        {
            var doc = Load();
            var entry = doc.Entries.Find(e => e.Id == entryId);
            if (entry == null || entry.Reverted) return false;

            try
            {
                OptCandidateFactory.RevertFromHistory(entry);
                entry.Reverted = true;
                Save();
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[AvatarScope] revert failed for {entry.Label}: {e.Message}");
                return false;
            }
        }

        public static void Clear()
        {
            Load().Entries.Clear();
            Save();
        }
    }
}

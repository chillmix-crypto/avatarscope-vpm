using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// A single non-destructive optimization candidate. Knows how to apply, revert,
    /// and pre-estimate its impact without actually executing.
    /// </summary>
    public interface IOptCandidate
    {
        string Label { get; }
        string Category { get; }
        Object TargetAsset { get; }

        long EstimatedDownloadDelta { get; } // negative = savings
        long EstimatedVRAMDelta { get; }

        bool RequiresVerification { get; }
        bool IsSelected { get; set; }

        bool IsApplicable();
        void Apply();
        void Revert();

        /// <summary>
        /// Serializable snapshot of the operation that allows it to be redone later by
        /// OptHistory. Returns null if the operation cannot be persisted across sessions
        /// (e.g. relies on transient asset references).
        /// </summary>
        OptHistoryEntry ToHistoryEntry();
    }

    public enum OptCategory
    {
        ReadWriteToggle,
        Crunch,
        TextureResize,
        MeshOptimize,
        BlendShape,
    }

    public static class OptCategoryStrings
    {
        public static string ToJapanese(OptCategory c)
        {
            switch (c)
            {
                case OptCategory.ReadWriteToggle: return "R/W 無効化";
                case OptCategory.Crunch:          return "Crunch 圧縮";
                case OptCategory.TextureResize:   return "テクスチャ縮小";
                case OptCategory.MeshOptimize:    return "メッシュ最適化";
                case OptCategory.BlendShape:      return "BlendShape";
                default:                          return c.ToString();
            }
        }
    }
}

using System.Collections.Generic;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// Visual Lossless Optimizer.
    /// Two-stage flow:
    ///   1. PrepareCandidates(avatar) — fast enumeration of every applicable optimization
    ///      with pre-calculated impact estimates. No assets are modified.
    ///   2. RunSelected(avatar, candidates) — user-selected candidates are applied with
    ///      per-step visual verification (SSIM) and automatic rollback on regression.
    /// </summary>
    public static class LosslessOptimizer
    {
        public class Report
        {
            public long   SizeBeforeBytes;
            public long   SizeAfterBytes;
            public double FinalAverageDiff;
            public double FinalWorstDiff;
            public int    AppliedCount;
            public int    RevertedCount;
            public int    SkippedCount;
            public List<string> AppliedLog  = new List<string>();
            public List<string> RevertedLog = new List<string>();
            public List<string> SkippedLog  = new List<string>();
            public string ErrorMessage;
            public double DurationSeconds;
            public Texture2D[] BeforeSnapshots;
            public Texture2D[] AfterSnapshots;
        }

        public const double DiffThreshold = 0.0025;
        public const int    SnapshotSize  = 384;

        // ---- Stage 1: collect candidates ----

        public static List<IOptCandidate> PrepareCandidates(GameObject avatar)
        {
            return OptCandidateFactory.CollectAll(avatar);
        }

        // ---- Stage 2: apply selected ----

        public static Report RunSelected(GameObject avatar, List<IOptCandidate> all)
        {
            var report = new Report();
            var sw = System.Diagnostics.Stopwatch.StartNew();
            if (avatar == null)
            {
                report.ErrorMessage = "Avatar is null.";
                return report;
            }

            // Filter to selected and applicable.
            var queue = new List<IOptCandidate>();
            foreach (var c in all)
            {
                if (c == null || !c.IsSelected) continue;
                queue.Add(c);
            }
            if (queue.Count == 0)
            {
                report.ErrorMessage = "No operations selected.";
                return report;
            }

            try
            {
                EditorUtility.DisplayProgressBar("AvatarScope Lossless", "Capturing baseline...", 0.02f);
                var baseline = AvatarSnapshotter.CaptureAllAngles(avatar, SnapshotSize);
                report.BeforeSnapshots = CloneTextures(baseline);

                report.SizeBeforeBytes = EstimateUploadBytes(avatar);

                int idx = 0;
                foreach (var op in queue)
                {
                    idx++;
                    EditorUtility.DisplayProgressBar(
                        "AvatarScope Lossless",
                        $"({idx}/{queue.Count}) {op.Label}",
                        0.05f + 0.9f * idx / queue.Count);

                    try
                    {
                        if (!op.IsApplicable())
                        {
                            report.SkippedCount++;
                            report.SkippedLog.Add($"{op.Label} (not applicable)");
                            continue;
                        }
                        op.Apply();
                    }
                    catch (System.Exception e)
                    {
                        report.SkippedCount++;
                        report.SkippedLog.Add($"{op.Label} (error: {e.Message})");
                        continue;
                    }

                    if (op.RequiresVerification)
                    {
                        AssetDatabase.SaveAssets();
                        AssetDatabase.Refresh();

                        var after = AvatarSnapshotter.CaptureAllAngles(avatar, SnapshotSize);
                        var diff = VisualDiffer.Compute(baseline, after);
                        AvatarSnapshotter.DisposeAll(after);

                        if (diff.WorstAngleDiff > DiffThreshold)
                        {
                            try { op.Revert(); } catch { /* best-effort */ }
                            AssetDatabase.SaveAssets();
                            report.RevertedCount++;
                            report.RevertedLog.Add($"{op.Label} (diff {diff.WorstAngleDiff:P2})");
                            continue;
                        }

                        AvatarSnapshotter.DisposeAll(baseline);
                        baseline = AvatarSnapshotter.CaptureAllAngles(avatar, SnapshotSize);
                    }

                    report.AppliedCount++;
                    report.AppliedLog.Add(op.Label);

                    var hist = op.ToHistoryEntry();
                    if (hist != null)
                    {
                        hist.AvatarName = avatar.name;
                        OptHistory.Append(hist);
                    }
                }

                EditorUtility.DisplayProgressBar("AvatarScope Lossless", "Final verification...", 0.97f);
                var finalSnap = AvatarSnapshotter.CaptureAllAngles(avatar, SnapshotSize);
                var finalDiff = VisualDiffer.Compute(report.BeforeSnapshots, finalSnap);
                AvatarSnapshotter.DisposeAll(baseline);
                report.AfterSnapshots = finalSnap;

                report.FinalAverageDiff = finalDiff.AverageDiff;
                report.FinalWorstDiff   = finalDiff.WorstAngleDiff;
                report.SizeAfterBytes   = EstimateUploadBytes(avatar);

                return report;
            }
            catch (System.Exception e)
            {
                report.ErrorMessage = e.Message;
                Debug.LogError($"[AvatarScope] Lossless optimizer error: {e}");
                AvatarSnapshotter.DisposeAll(report.BeforeSnapshots);
                AvatarSnapshotter.DisposeAll(report.AfterSnapshots);
                report.BeforeSnapshots = null;
                report.AfterSnapshots = null;
                return report;
            }
            finally
            {
                EditorUtility.ClearProgressBar();
                sw.Stop();
                report.DurationSeconds = sw.Elapsed.TotalSeconds;
            }
        }

        // ---- helpers ----

        private static Texture2D[] CloneTextures(Texture2D[] src)
        {
            if (src == null) return null;
            var dst = new Texture2D[src.Length];
            for (int i = 0; i < src.Length; i++)
            {
                if (src[i] == null) continue;
                var t = new Texture2D(src[i].width, src[i].height, src[i].format, false);
                t.SetPixels32(src[i].GetPixels32());
                t.Apply(false);
                dst[i] = t;
            }
            return dst;
        }

        private static long EstimateUploadBytes(GameObject avatar)
        {
            var visited = new HashSet<Object>();
            long total = 0;
            foreach (var comp in avatar.GetComponentsInChildren<Component>(true))
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null || !visited.Add(obj)) continue;
                    total += AssetSizeEstimator.Estimate(obj).DownloadBytes;
                }
            }
            foreach (var smr in avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (smr != null && smr.sharedMesh != null && visited.Add(smr.sharedMesh))
                    total += AssetSizeEstimator.Estimate(smr.sharedMesh).DownloadBytes;
            }
            foreach (var mf in avatar.GetComponentsInChildren<MeshFilter>(true))
            {
                if (mf != null && mf.sharedMesh != null && visited.Add(mf.sharedMesh))
                    total += AssetSizeEstimator.Estimate(mf.sharedMesh).DownloadBytes;
            }
            return total;
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// Builds the list of optimization candidates for an avatar and dispatches
    /// history-entry reverts back to the right concrete candidate class.
    /// </summary>
    public static class OptCandidateFactory
    {
        public static List<IOptCandidate> CollectAll(GameObject avatar)
        {
            var list = new List<IOptCandidate>();
            if (avatar == null) return list;

            var visited = new HashSet<UnityEngine.Object>();
            var components = avatar.GetComponentsInChildren<Component>(true);

            foreach (var comp in components)
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null || !visited.Add(obj)) continue;
                    AddForAsset(obj, avatar, list);
                }
            }

            foreach (var smr in avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (smr != null && smr.sharedMesh != null && visited.Add(smr.sharedMesh))
                    AddForAsset(smr.sharedMesh, avatar, list);
            }
            foreach (var mf in avatar.GetComponentsInChildren<MeshFilter>(true))
            {
                if (mf != null && mf.sharedMesh != null && visited.Add(mf.sharedMesh))
                    AddForAsset(mf.sharedMesh, avatar, list);
            }

            // BlendShape report (per renderer).
            var bsReports = BlendShapeUsageAnalyzer.Analyze(avatar);
            foreach (var r in bsReports)
            {
                if (r.UnusedShapes == null || r.UnusedShapes.Count == 0) continue;
                list.Add(new BlendShapeUnusedReportCandidate(r));
            }

            return list;
        }

        private static void AddForAsset(UnityEngine.Object obj, GameObject avatar, List<IOptCandidate> list)
        {
            string path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) return;
            if (path.StartsWith("Library/") || path.StartsWith("Resources/unity_builtin")) return;

            if (obj is Texture2D tex)
            {
                var ti = AssetImporter.GetAtPath(path) as TextureImporter;
                if (ti == null) return;

                if (ti.isReadable) list.Add(new TextureReadWriteOp(path, tex));
                if (!ti.crunchedCompression && ti.textureType != TextureImporterType.NormalMap)
                    list.Add(new TextureCrunchOp(path, tex));

                // UV-density based resize candidate
                try
                {
                    var report = UVDensityAnalyzer.Analyze(tex, avatar);
                    if (report.CanReduce)
                    {
                        list.Add(new TextureResizeOp(path, tex, ti.maxTextureSize, report.OptimalResolution, report));
                    }
                }
                catch (Exception e) { Debug.LogWarning($"[AvatarScope] UV density on {path} failed: {e.Message}"); }
            }
            else if (obj is Mesh)
            {
                var mi = AssetImporter.GetAtPath(path) as ModelImporter;
                if (mi != null)
                {
                    // NOTE: We intentionally do NOT offer Mesh R/W disable.
                    // VRChat avatar upload validation REQUIRES mesh R/W to be enabled,
                    // so disabling it would break uploads. (Texture R/W disable is fine.)
                    if (!mi.optimizeMeshPolygons || !mi.optimizeMeshVertices)
                        list.Add(new MeshOptimizeOp(path));
                }
            }
        }

        // ---- history revert dispatch ----

        public static void RevertFromHistory(OptHistoryEntry entry)
        {
            if (entry == null) return;
            switch (entry.OpKind)
            {
                case "TextureRW": TextureReadWriteOp.RevertFromHistory(entry); break;
                case "Crunch":    TextureCrunchOp.RevertFromHistory(entry);    break;
                case "Resize":    TextureResizeOp.RevertFromHistory(entry);    break;
                case "MeshRW":    MeshReadWriteOp.RevertFromHistory(entry);    break;
                case "MeshOpt":   MeshOptimizeOp.RevertFromHistory(entry);     break;
                default:
                    Debug.LogWarning($"[AvatarScope] Unknown OpKind {entry.OpKind}, cannot revert.");
                    break;
            }
        }
    }

    // ============ Concrete candidates ============

    public abstract class TextureCandidateBase : IOptCandidate
    {
        protected readonly string _path;
        protected readonly Texture2D _texture;

        public TextureCandidateBase(string path, Texture2D tex)
        {
            _path = path;
            _texture = tex;
        }

        public abstract string Label { get; }
        public abstract string Category { get; }
        public UnityEngine.Object TargetAsset => _texture;
        public long EstimatedDownloadDelta { get; protected set; }
        public long EstimatedVRAMDelta { get; protected set; }
        public abstract bool RequiresVerification { get; }
        public bool IsSelected { get; set; } = true;
        public abstract bool IsApplicable();
        public abstract void Apply();
        public abstract void Revert();
        public abstract OptHistoryEntry ToHistoryEntry();
    }

    // ---- Texture: R/W disable ----

    public class TextureReadWriteOp : TextureCandidateBase
    {
        private bool _prev;
        public TextureReadWriteOp(string path, Texture2D tex) : base(path, tex)
        {
            // R/W enabled doubles the texture memory at runtime.
            EstimatedVRAMDelta = -(TextureSizeCalculator.GetVRAMBytes(tex));
            EstimatedDownloadDelta = 0;
        }

        public override string Label => $"R/W 無効化: {Path.GetFileName(_path)}";
        public override string Category => "R/W 無効化";
        public override bool RequiresVerification => false;

        public override bool IsApplicable()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            return ti != null && ti.isReadable;
        }
        public override void Apply()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            _prev = ti.isReadable;
            ti.isReadable = false;
            ti.SaveAndReimport();
        }
        public override void Revert()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            ti.isReadable = _prev;
            ti.SaveAndReimport();
        }

        public override OptHistoryEntry ToHistoryEntry() => new OptHistoryEntry
        {
            TimestampUtc = System.DateTime.UtcNow.Ticks,
            AssetPath = _path,
            Category = Category,
            Label = Label,
            OpKind = "TextureRW",
            PreviousJson = _prev ? "1" : "0",
            DeltaDownloadBytes = EstimatedDownloadDelta,
            DeltaVRAMBytes = EstimatedVRAMDelta,
        };

        public static void RevertFromHistory(OptHistoryEntry e)
        {
            var ti = AssetImporter.GetAtPath(e.AssetPath) as TextureImporter;
            if (ti == null) return;
            ti.isReadable = e.PreviousJson == "1";
            ti.SaveAndReimport();
        }
    }

    // ---- Texture: Crunch ----

    public class TextureCrunchOp : TextureCandidateBase
    {
        private bool _prev;
        private int  _prevQuality;
        public TextureCrunchOp(string path, Texture2D tex) : base(path, tex)
        {
            long vram = TextureSizeCalculator.GetVRAMBytes(tex);
            EstimatedDownloadDelta = -(long)(vram * 0.65);
            EstimatedVRAMDelta = 0;
        }

        public override string Label => $"Crunch 圧縮: {Path.GetFileName(_path)}";
        public override string Category => "Crunch 圧縮";
        public override bool RequiresVerification => true;

        public override bool IsApplicable()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            return ti != null && !ti.crunchedCompression && ti.textureType != TextureImporterType.NormalMap;
        }
        public override void Apply()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            _prev = ti.crunchedCompression;
            _prevQuality = ti.compressionQuality;
            ti.crunchedCompression = true;
            ti.compressionQuality = 75;
            ti.SaveAndReimport();
        }
        public override void Revert()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            ti.crunchedCompression = _prev;
            ti.compressionQuality = _prevQuality;
            ti.SaveAndReimport();
        }

        public override OptHistoryEntry ToHistoryEntry() => new OptHistoryEntry
        {
            TimestampUtc = System.DateTime.UtcNow.Ticks,
            AssetPath = _path,
            Category = Category,
            Label = Label,
            OpKind = "Crunch",
            PreviousJson = $"{(_prev?1:0)},{_prevQuality}",
            DeltaDownloadBytes = EstimatedDownloadDelta,
        };

        public static void RevertFromHistory(OptHistoryEntry e)
        {
            var ti = AssetImporter.GetAtPath(e.AssetPath) as TextureImporter;
            if (ti == null) return;
            var parts = (e.PreviousJson ?? "0,50").Split(',');
            ti.crunchedCompression = parts.Length > 0 && parts[0] == "1";
            if (parts.Length > 1 && int.TryParse(parts[1], out var q)) ti.compressionQuality = q;
            ti.SaveAndReimport();
        }
    }

    // ---- Texture: UV-density Resize ----

    public class TextureResizeOp : TextureCandidateBase
    {
        private readonly int _currentSize;
        private readonly int _targetSize;
        private readonly UVDensityAnalyzer.Report _report;
        private int _prev;

        public TextureResizeOp(string path, Texture2D tex, int currentSize, int targetSize, UVDensityAnalyzer.Report report)
            : base(path, tex)
        {
            _currentSize = currentSize;
            _targetSize  = targetSize;
            _report = report;
            // VRAM scales with area: (target/current)^2
            double ratio = (double)targetSize * targetSize / (currentSize * currentSize);
            long vram = TextureSizeCalculator.GetVRAMBytes(tex);
            long newVram = (long)(vram * ratio);
            EstimatedVRAMDelta = newVram - vram;        // negative
            EstimatedDownloadDelta = EstimatedVRAMDelta; // proportional for textures
        }

        public override string Label =>
            $"テクスチャ縮小 (UV{_report.CoveragePercent:F0}%): {Path.GetFileName(_path)} {_currentSize}→{_targetSize}";
        public override string Category => "テクスチャ縮小 (UV密度)";
        public override bool RequiresVerification => true;

        public override bool IsApplicable()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            return ti != null && ti.maxTextureSize > _targetSize;
        }
        public override void Apply()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            _prev = ti.maxTextureSize;
            ti.maxTextureSize = _targetSize;
            ti.SaveAndReimport();
        }
        public override void Revert()
        {
            var ti = AssetImporter.GetAtPath(_path) as TextureImporter;
            if (ti == null) return;
            ti.maxTextureSize = _prev;
            ti.SaveAndReimport();
        }

        public override OptHistoryEntry ToHistoryEntry() => new OptHistoryEntry
        {
            TimestampUtc = System.DateTime.UtcNow.Ticks,
            AssetPath = _path,
            Category = Category,
            Label = Label,
            OpKind = "Resize",
            PreviousJson = _prev.ToString(),
            DeltaDownloadBytes = EstimatedDownloadDelta,
            DeltaVRAMBytes = EstimatedVRAMDelta,
        };

        public static void RevertFromHistory(OptHistoryEntry e)
        {
            var ti = AssetImporter.GetAtPath(e.AssetPath) as TextureImporter;
            if (ti == null) return;
            if (int.TryParse(e.PreviousJson, out var s)) ti.maxTextureSize = s;
            ti.SaveAndReimport();
        }
    }

    // ---- Mesh: R/W disable ----

    public class MeshReadWriteOp : IOptCandidate
    {
        private readonly string _path;
        private bool _prev;
        public MeshReadWriteOp(string path) { _path = path; }

        public string Label => $"Mesh R/W 無効化: {Path.GetFileName(_path)}";
        public string Category => "Mesh R/W 無効化";
        public UnityEngine.Object TargetAsset => AssetDatabase.LoadMainAssetAtPath(_path);
        public long EstimatedDownloadDelta => 0;
        public long EstimatedVRAMDelta => 0;
        public bool RequiresVerification => false;
        public bool IsSelected { get; set; } = true;

        public bool IsApplicable()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            return mi != null && mi.isReadable;
        }
        public void Apply()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            if (mi == null) return;
            _prev = mi.isReadable;
            mi.isReadable = false;
            mi.SaveAndReimport();
        }
        public void Revert()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            if (mi == null) return;
            mi.isReadable = _prev;
            mi.SaveAndReimport();
        }

        public OptHistoryEntry ToHistoryEntry() => new OptHistoryEntry
        {
            TimestampUtc = System.DateTime.UtcNow.Ticks,
            AssetPath = _path,
            Category = Category,
            Label = Label,
            OpKind = "MeshRW",
            PreviousJson = _prev ? "1" : "0",
        };

        public static void RevertFromHistory(OptHistoryEntry e)
        {
            var mi = AssetImporter.GetAtPath(e.AssetPath) as ModelImporter;
            if (mi == null) return;
            mi.isReadable = e.PreviousJson == "1";
            mi.SaveAndReimport();
        }
    }

    // ---- Mesh: Optimize ----

    public class MeshOptimizeOp : IOptCandidate
    {
        private readonly string _path;
        private bool _prevP, _prevV;
        public MeshOptimizeOp(string path) { _path = path; }

        public string Label => $"Mesh 最適化: {Path.GetFileName(_path)}";
        public string Category => "メッシュ最適化";
        public UnityEngine.Object TargetAsset => AssetDatabase.LoadMainAssetAtPath(_path);
        public long EstimatedDownloadDelta => 0;
        public long EstimatedVRAMDelta => 0;
        public bool RequiresVerification => false;
        public bool IsSelected { get; set; } = true;

        public bool IsApplicable()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            return mi != null && (!mi.optimizeMeshPolygons || !mi.optimizeMeshVertices);
        }
        public void Apply()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            if (mi == null) return;
            _prevP = mi.optimizeMeshPolygons;
            _prevV = mi.optimizeMeshVertices;
            mi.optimizeMeshPolygons = true;
            mi.optimizeMeshVertices = true;
            mi.SaveAndReimport();
        }
        public void Revert()
        {
            var mi = AssetImporter.GetAtPath(_path) as ModelImporter;
            if (mi == null) return;
            mi.optimizeMeshPolygons = _prevP;
            mi.optimizeMeshVertices = _prevV;
            mi.SaveAndReimport();
        }

        public OptHistoryEntry ToHistoryEntry() => new OptHistoryEntry
        {
            TimestampUtc = System.DateTime.UtcNow.Ticks,
            AssetPath = _path,
            Category = Category,
            Label = Label,
            OpKind = "MeshOpt",
            PreviousJson = $"{(_prevP?1:0)},{(_prevV?1:0)}",
        };

        public static void RevertFromHistory(OptHistoryEntry e)
        {
            var mi = AssetImporter.GetAtPath(e.AssetPath) as ModelImporter;
            if (mi == null) return;
            var parts = (e.PreviousJson ?? "0,0").Split(',');
            mi.optimizeMeshPolygons = parts.Length > 0 && parts[0] == "1";
            mi.optimizeMeshVertices = parts.Length > 1 && parts[1] == "1";
            mi.SaveAndReimport();
        }
    }

    // ---- BlendShape: report-only ----
    // True non-destructive removal of BlendShapes requires either AAO or a new mesh asset.
    // For v0.9 we expose the *information* as a candidate that, when "applied",
    // shows a dialog with the unused list and a one-click "Select in Hierarchy" jump.

    public class BlendShapeUnusedReportCandidate : IOptCandidate
    {
        private readonly BlendShapeUsageAnalyzer.Report _report;
        public BlendShapeUnusedReportCandidate(BlendShapeUsageAnalyzer.Report r)
        {
            _report = r;
        }

        public string Label =>
            $"未使用 BlendShape 検出: {_report.Renderer.name} ({_report.UnusedShapes.Count} 件)";
        public string Category => "未使用 BlendShape";
        public UnityEngine.Object TargetAsset => _report.Renderer;
        // Rough estimate: 15% of blendshape data per shape.
        public long EstimatedDownloadDelta
        {
            get
            {
                if (_report.Renderer == null || _report.Renderer.sharedMesh == null) return 0;
                int v = _report.Renderer.sharedMesh.vertexCount;
                // 40 bytes per modified vertex, ~15% modified per shape, LZMA 0.5
                return -(long)(_report.UnusedShapes.Count * v * 40L * 0.15 * 0.5);
            }
        }
        public long EstimatedVRAMDelta => 0;
        public bool RequiresVerification => false;
        public bool IsSelected { get; set; } = true;

        public bool IsApplicable() => _report.UnusedShapes != null && _report.UnusedShapes.Count > 0;
        public void Apply()
        {
            // Report-only in v0.9. Selecting the renderer so the user can act.
            UnityEditor.Selection.activeObject = _report.Renderer;
            UnityEditor.EditorGUIUtility.PingObject(_report.Renderer);
            Debug.Log($"[AvatarScope] Unused BlendShapes on {_report.Renderer.name}:\n  " +
                      string.Join("\n  ", _report.UnusedShapes));
        }
        public void Revert() { /* no-op */ }

        public OptHistoryEntry ToHistoryEntry() => null;
    }
}

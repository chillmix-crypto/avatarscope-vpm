using Chill.AvatarScope.Editor.Analyzers;
using Chill.AvatarScope.Editor.Util;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    /// <summary>
    /// Runs each Analyzer against the target avatar and returns a populated MetricsResult.
    /// When NDMF (Modular Avatar) is installed and simulateMA is true, a clone of the avatar
    /// is processed through the NDMF pipeline first so the metrics reflect the post-merge state
    /// — which is what VRChat actually receives at upload.
    /// </summary>
    public static class MetricsCollector
    {
        public static MetricsResult Collect(GameObject avatar, bool simulateMA = true, bool measureRealSize = false)
        {
            var result = new MetricsResult();
            if (avatar == null) return result;

            result.HasAvatar = true;
            result.AvatarName = avatar.name;

            // Clean up any lingering clones from a previous failed run.
            MABuildSimulator.RemoveLingeringClones();

            GameObject clone = null;
            GameObject target = avatar;

            if (simulateMA && MABuildSimulator.IsAvailable)
            {
                clone = MABuildSimulator.SimulateBuild(avatar);
                if (clone != null)
                {
                    target = clone;
                    result.MASimulationActive = true;
                }
            }

            try
            {
                SizeAnalyzer.Analyze(target, result);
                PerformanceAnalyzer.Analyze(target, result);
                PerformanceRankAnalyzer.Analyze(target, result);
                ParameterAnalyzer.Analyze(target, result);
                CompatibilityChecker.Analyze(target, result);

                // Breakdown tree should always reflect what the user can interact with (the source avatar).
                result.BreakdownGameObject = BreakdownBuilder.BuildGameObjectView(avatar);
                result.BreakdownAsset = BreakdownBuilder.BuildAssetView(avatar);

                if (measureRealSize)
                {
                    // Use the target (post-MA-simulation if active) so the measured bundle
                    // matches what VRChat would actually upload.
                    UnityEditor.EditorUtility.DisplayProgressBar(
                        "AvatarScope",
                        "Building AssetBundle (PC) to measure real download size...",
                        0.5f);
                    try
                    {
                        var pcResult = AssetBundleSizeMeasurer.Measure(
                            target, UnityEditor.BuildTarget.StandaloneWindows64);
                        if (pcResult.Success)
                            result.RealDownloadBytesPC = pcResult.BundleSizeBytes;
                        else
                            result.RealMeasurementError = pcResult.FailureReason;
                        result.RealMeasurementSeconds = pcResult.DurationSeconds;
                        result.RealMeasurementMethod = pcResult.MethodUsed;
                    }
                    finally
                    {
                        UnityEditor.EditorUtility.ClearProgressBar();
                    }
                }
            }
            finally
            {
                MABuildSimulator.Cleanup(clone);
            }

            return result;
        }
    }
}

using System.Collections.Generic;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Core
{
    public enum MetricStatus
    {
        Safe,
        Caution,
        Heavy,
        Critical,
    }

    public enum BreakdownViewMode
    {
        GameObject,
        Asset,
    }

    public enum BreakdownSortMode
    {
        FileSize,
        VRAM,
        Polygons,
        PhysBones,
    }

    public class BreakdownItem
    {
        public string Name;
        public string IconPath;
        public Object UnityObject;
        public long FileSizeBytes;
        public long VRAMBytes;
        public int Polygons;
        public int Materials;
        public int PhysBones;
        public int Colliders;
        public List<BreakdownItem> Children = new List<BreakdownItem>();
        public int Depth;
    }

    public class MetricsResult
    {
        public enum VRCRank { None, Excellent, Good, Medium, Poor, VeryPoor }

        public string AvatarName = "(none)";
        public bool HasAvatar;

        public long DownloadEstimateBytes;
        public long UploadEstimateBytes;
        public long VRAMEstimateBytes;

        // Real AssetBundle measurement (only filled when "Measure real size" is enabled).
        public long? RealDownloadBytesPC;
        public long? RealDownloadBytesQuest;
        public string RealMeasurementError;
        public double RealMeasurementSeconds;
        public string RealMeasurementMethod;   // "VRC SDK exact (...)" or "Unity BuildPipeline (...)"

        public int Polygons;
        public int Materials;
        public int PhysBones;
        public int Colliders;
        public int PhysBoneTransforms;
        public int PhysBoneCollisionChecks;
        public int SkinnedMeshes;
        public int Meshes;
        public int ShaderKeywords;

        // Extended stats matching VRChat's Avatar Performance panel
        public UnityEngine.Vector3? BoundsSize;
        public int Bones;
        public int Lights;
        public int Animators;
        public int Contacts;
        public int Constraints;
        public int ConstraintDepth;
        public int ParticleSystems;
        public int ParticleMaxTotal;
        public int ParticleMeshPolygons;
        public bool ParticleTrails;
        public bool ParticleCollision;
        public int TrailRenderers;
        public int LineRenderers;
        public int ClothMeshes;
        public int ClothMaxVertices;
        public int PhysicsColliders;
        public int PhysicsRigidbodies;
        public int AudioSources;
        public int Raycasts;
        public long UncompressedBytes;

        // Official VRChat performance rank (computed by VRC SDK API).
        public VRCRank RankPC = VRCRank.None;
        public VRCRank RankQuest = VRCRank.None;
        public System.Collections.Generic.Dictionary<string, VRCRank> PerCategoryPC
            = new System.Collections.Generic.Dictionary<string, VRCRank>();
        public System.Collections.Generic.Dictionary<string, VRCRank> PerCategoryQuest
            = new System.Collections.Generic.Dictionary<string, VRCRank>();

        public int ParamBitsUsed;
        public int ParamBitsMax = 256;
        public int ParamCountBool;
        public int ParamCountInt;
        public int ParamCountFloat;

        public bool MASimulationActive;

        public bool PCUploadOK = true;
        public string PCUploadMessage = "OK";
        public bool QuestCompatible;
        public string QuestMessage = "Not checked";
        public bool FallbackEligible;
        public string FallbackMessage = "Not checked";
        public bool FacetraReady;
        public string FacetraMessage = "Not checked";

        public List<BreakdownItem> BreakdownGameObject = new List<BreakdownItem>();
        public List<BreakdownItem> BreakdownAsset = new List<BreakdownItem>();
    }
}

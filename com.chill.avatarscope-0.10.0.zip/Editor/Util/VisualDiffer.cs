using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Computes the average per-pixel difference between two snapshot sets.
    /// Returns 0.0 (identical) to 1.0 (completely different).
    /// We use a fast mean-absolute-difference rather than full SSIM — sufficient for
    /// detecting visible texture-quality regressions while staying CPU-cheap.
    /// </summary>
    public static class VisualDiffer
    {
        public struct DiffReport
        {
            public double AverageDiff;     // 0..1 across all angles
            public double WorstAngleDiff;  // worst single angle
            public int    Angles;
        }

        public static DiffReport Compute(Texture2D[] before, Texture2D[] after)
        {
            var r = new DiffReport();
            if (before == null || after == null) return r;
            int n = Mathf.Min(before.Length, after.Length);
            if (n == 0) return r;

            double sum = 0;
            double worst = 0;

            for (int i = 0; i < n; i++)
            {
                if (before[i] == null || after[i] == null) continue;
                double d = ComputeSinglePair(before[i], after[i]);
                sum += d;
                if (d > worst) worst = d;
            }

            r.AverageDiff = sum / n;
            r.WorstAngleDiff = worst;
            r.Angles = n;
            return r;
        }

        private static double ComputeSinglePair(Texture2D a, Texture2D b)
        {
            if (a == null || b == null) return 1;
            if (a.width != b.width || a.height != b.height) return 1;

            var pa = a.GetPixels32();
            var pb = b.GetPixels32();
            if (pa.Length != pb.Length || pa.Length == 0) return 1;

            long acc = 0;
            for (int i = 0; i < pa.Length; i++)
            {
                int dr = pa[i].r - pb[i].r;
                int dg = pa[i].g - pb[i].g;
                int db = pa[i].b - pb[i].b;
                if (dr < 0) dr = -dr;
                if (dg < 0) dg = -dg;
                if (db < 0) db = -db;
                acc += dr + dg + db;
            }
            // Normalize: pa.Length * 3 channels * 255 max
            double maxAcc = (double)pa.Length * 3 * 255;
            return acc / maxAcc;
        }
    }
}

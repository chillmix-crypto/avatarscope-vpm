using Chill.AvatarScope.Editor.Core;

namespace Chill.AvatarScope.Editor.Util
{
    public static class ColorThresholds
    {
        public static MetricStatus FromPercent(double percent)
        {
            if (percent < 5.0)  return MetricStatus.Safe;
            if (percent < 15.0) return MetricStatus.Caution;
            if (percent < 30.0) return MetricStatus.Heavy;
            return MetricStatus.Critical;
        }

        public static MetricStatus FromUsage(double used, double max)
        {
            if (max <= 0) return MetricStatus.Safe;
            return FromUsageRatio(used / max);
        }

        public static MetricStatus FromUsageRatio(double ratio)
        {
            if (ratio < 0.50) return MetricStatus.Safe;
            if (ratio < 0.75) return MetricStatus.Caution;
            if (ratio < 1.00) return MetricStatus.Heavy;
            return MetricStatus.Critical;
        }

        public static string ToUssClass(MetricStatus s)
        {
            switch (s)
            {
                case MetricStatus.Safe:     return "status-safe";
                case MetricStatus.Caution:  return "status-caution";
                case MetricStatus.Heavy:    return "status-heavy";
                case MetricStatus.Critical: return "status-critical";
            }
            return "status-safe";
        }

        public static string ToBarClass(MetricStatus s)
        {
            switch (s)
            {
                case MetricStatus.Safe:     return "bar-safe";
                case MetricStatus.Caution:  return "bar-caution";
                case MetricStatus.Heavy:    return "bar-heavy";
                case MetricStatus.Critical: return "bar-critical";
            }
            return "bar-safe";
        }

        public static string ToLabel(MetricStatus s)
        {
            switch (s)
            {
                case MetricStatus.Safe:     return "SAFE";
                case MetricStatus.Caution:  return "CAUTN";
                case MetricStatus.Heavy:    return "HEAVY";
                case MetricStatus.Critical: return "CRIT";
            }
            return "";
        }

        public static string FormatBytes(long bytes)
        {
            if (bytes < 1024)       return $"{bytes} B";
            if (bytes < 1024L * 1024)
                return $"{bytes / 1024.0:F1} KB";
            if (bytes < 1024L * 1024 * 1024)
                return $"{bytes / (1024.0 * 1024):F1} MB";
            return $"{bytes / (1024.0 * 1024 * 1024):F2} GB";
        }
    }
}

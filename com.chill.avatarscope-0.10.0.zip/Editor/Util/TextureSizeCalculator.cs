using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Texture VRAM size calculator.
    /// Primary: reflection to UnityEditor.TextureUtil.GetStorageMemorySizeLong (most accurate, used by Unity itself).
    /// Fallback: format-based formula.
    /// </summary>
    public static class TextureSizeCalculator
    {
        private static MethodInfo s_storageMethod;
        private static bool s_resolved;

        private static MethodInfo ResolveStorageMethod()
        {
            if (s_resolved) return s_storageMethod;
            s_resolved = true;
            try
            {
                var asm = typeof(AssetDatabase).Assembly;
                var t = asm.GetType("UnityEditor.TextureUtil");
                if (t != null)
                {
                    s_storageMethod = t.GetMethod(
                        "GetStorageMemorySizeLong",
                        BindingFlags.Static | BindingFlags.Public,
                        null,
                        new[] { typeof(Texture) },
                        null);
                }
            }
            catch { /* ignore */ }
            return s_storageMethod;
        }

        public static long GetVRAMBytes(Texture texture)
        {
            if (texture == null) return 0;
            var m = ResolveStorageMethod();
            if (m != null)
            {
                try
                {
                    return (long)m.Invoke(null, new object[] { texture });
                }
                catch { /* fall through to formula */ }
            }
            return EstimateByFormula(texture);
        }

        private static long EstimateByFormula(Texture tex)
        {
            int w = tex.width;
            int h = tex.height;
            long pixels = (long)w * h;

            double bpp = BytesPerPixel(tex);
            long baseSize = (long)(pixels * bpp);

            bool hasMips = false;
            if (tex is Texture2D t2d) hasMips = t2d.mipmapCount > 1;
            else if (tex is Cubemap cm) hasMips = cm.mipmapCount > 1;

            // Sum mipmap chain: 1 + 1/4 + 1/16 + ... ~= 4/3
            return hasMips ? (long)(baseSize * 1.333) : baseSize;
        }

        /// <summary>
        /// Bytes-per-pixel for common formats. Used only as fallback.
        /// </summary>
        private static double BytesPerPixel(Texture tex)
        {
            TextureFormat fmt = TextureFormat.RGBA32;
            if (tex is Texture2D t2d) fmt = t2d.format;
            else if (tex is Cubemap cm) fmt = cm.format;

            switch (fmt)
            {
                // Uncompressed
                case TextureFormat.Alpha8:          return 1;
                case TextureFormat.R8:              return 1;
                case TextureFormat.R16:             return 2;
                case TextureFormat.RG16:            return 2;
                case TextureFormat.RGB24:           return 3;
                case TextureFormat.RGBA32:          return 4;
                case TextureFormat.ARGB32:          return 4;
                case TextureFormat.BGRA32:          return 4;
                case TextureFormat.RGBAFloat:       return 16;
                case TextureFormat.RGBAHalf:        return 8;
                case TextureFormat.RFloat:          return 4;
                case TextureFormat.RHalf:           return 2;

                // BC (DXT / BPTC)
                case TextureFormat.DXT1:            return 0.5;
                case TextureFormat.DXT1Crunched:    return 0.5;
                case TextureFormat.DXT5:            return 1;
                case TextureFormat.DXT5Crunched:    return 1;
                case TextureFormat.BC4:             return 0.5;
                case TextureFormat.BC5:             return 1;
                case TextureFormat.BC6H:            return 1;
                case TextureFormat.BC7:             return 1;

                // ETC
                case TextureFormat.ETC_RGB4:        return 0.5;
                case TextureFormat.ETC2_RGB:        return 0.5;
                case TextureFormat.ETC2_RGBA1:      return 0.5;
                case TextureFormat.ETC2_RGBA8:      return 1;

                // ASTC (block-based, bpp = 128 / (blockX * blockY))
                case TextureFormat.ASTC_4x4:        return 128.0 / (4 * 4) / 8;
                case TextureFormat.ASTC_5x5:        return 128.0 / (5 * 5) / 8;
                case TextureFormat.ASTC_6x6:        return 128.0 / (6 * 6) / 8;
                case TextureFormat.ASTC_8x8:        return 128.0 / (8 * 8) / 8;
                case TextureFormat.ASTC_10x10:      return 128.0 / (10 * 10) / 8;
                case TextureFormat.ASTC_12x12:      return 128.0 / (12 * 12) / 8;

                default:                            return 4;
            }
        }
    }
}

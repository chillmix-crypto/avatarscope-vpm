using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Captures a fixed-angle render of the avatar to a Texture2D set.
    /// Used to compare visual state before/after optimization operations.
    /// </summary>
    public static class AvatarSnapshotter
    {
        public const int DefaultSize = 512;

        // Camera positions relative to the avatar bounds center, in units of avatar height.
        // [forward distance, vertical offset, side offset, look-down]
        private static readonly Vector3[] CameraOffsets =
        {
            new Vector3(0,     0.5f, -2.0f),   // front
            new Vector3(0,     0.5f,  2.0f),   // back
            new Vector3(-2.0f, 0.5f,  0),      // left
            new Vector3( 2.0f, 0.5f,  0),      // right
        };

        public static Texture2D[] CaptureAllAngles(GameObject avatar, int size = DefaultSize)
        {
            var result = new Texture2D[CameraOffsets.Length];
            if (avatar == null) return result;

            // Compute avatar bounds in world space.
            var bounds = CalculateBounds(avatar);
            float h = Mathf.Max(0.5f, bounds.size.y);

            // Spawn a temporary camera.
            var camGo = new GameObject("__AvatarScope_SnapCam");
            camGo.hideFlags = HideFlags.HideAndDontSave;
            var cam = camGo.AddComponent<Camera>();
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.18f, 0.18f, 0.18f, 1f);
            cam.orthographic = false;
            cam.fieldOfView = 35f;
            cam.nearClipPlane = 0.05f;
            cam.farClipPlane = 1000f;
            cam.cullingMask = ~0;

            var rt = RenderTexture.GetTemporary(size, size, 16, RenderTextureFormat.ARGB32);
            cam.targetTexture = rt;

            try
            {
                for (int i = 0; i < CameraOffsets.Length; i++)
                {
                    var off = CameraOffsets[i];
                    var pos = bounds.center + new Vector3(off.x * h, off.y * h, off.z * h);
                    cam.transform.position = pos;
                    cam.transform.LookAt(bounds.center);

                    cam.Render();

                    var prev = RenderTexture.active;
                    RenderTexture.active = rt;
                    var tex = new Texture2D(size, size, TextureFormat.RGBA32, false, false);
                    tex.ReadPixels(new Rect(0, 0, size, size), 0, 0, false);
                    tex.Apply(false);
                    RenderTexture.active = prev;

                    result[i] = tex;
                }
            }
            finally
            {
                cam.targetTexture = null;
                RenderTexture.ReleaseTemporary(rt);
                Object.DestroyImmediate(camGo);
            }

            return result;
        }

        private static Bounds CalculateBounds(GameObject avatar)
        {
            var renderers = avatar.GetComponentsInChildren<Renderer>(true);
            if (renderers == null || renderers.Length == 0)
            {
                return new Bounds(avatar.transform.position, Vector3.one);
            }

            bool init = false;
            Bounds total = new Bounds();
            foreach (var r in renderers)
            {
                if (r == null || !r.enabled) continue;
                if (!init) { total = r.bounds; init = true; }
                else       { total.Encapsulate(r.bounds); }
            }
            if (!init) total = new Bounds(avatar.transform.position, Vector3.one);
            return total;
        }

        public static void DisposeAll(Texture2D[] textures)
        {
            if (textures == null) return;
            foreach (var t in textures)
            {
                if (t != null) Object.DestroyImmediate(t);
            }
        }
    }
}

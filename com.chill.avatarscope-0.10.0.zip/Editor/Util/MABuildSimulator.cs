using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Optionally runs the Modular Avatar / NDMF non-destructive build pipeline on a clone
    /// of the avatar so we can measure the post-merge state (what VRChat actually receives).
    ///
    /// Uses reflection so the package compiles and runs even when NDMF is not installed.
    /// If NDMF is missing or the simulation fails, callers fall back to the raw edit-time tree.
    /// </summary>
    public static class MABuildSimulator
    {
        private const string CloneTag = "__AvatarScope_TempClone";

        private static Type s_processorType;
        private static MethodInfo s_processMethod;
        private static bool s_resolved;

        public static bool IsAvailable
        {
            get
            {
                Resolve();
                return s_processMethod != null;
            }
        }

        private static void Resolve()
        {
            if (s_resolved) return;
            s_resolved = true;
            try
            {
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    var t = asm.GetType("nadena.dev.ndmf.AvatarProcessor");
                    if (t != null)
                    {
                        s_processorType = t;
                        break;
                    }
                }
                if (s_processorType == null) return;

                // Try common signatures: ProcessAvatar(GameObject) - static
                s_processMethod = s_processorType.GetMethod(
                    "ProcessAvatar",
                    BindingFlags.Public | BindingFlags.Static,
                    null,
                    new[] { typeof(GameObject) },
                    null);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AvatarScope] NDMF lookup failed: {e.Message}");
            }
        }

        /// <summary>
        /// Instantiates a clone of the avatar and runs the NDMF pipeline on it.
        /// Caller MUST call Cleanup on the returned object.
        /// Returns null if NDMF is not available or simulation failed.
        /// </summary>
        public static GameObject SimulateBuild(GameObject avatar)
        {
            if (avatar == null) return null;
            Resolve();
            if (s_processMethod == null) return null;

            GameObject clone = null;
            try
            {
                clone = UnityEngine.Object.Instantiate(avatar);
                clone.name = CloneTag;

                // Move far away so it doesn't visually pop up in the user's scene.
                clone.transform.position = new Vector3(99999, -99999, 99999);

                // Trigger the NDMF / Modular Avatar build pipeline on the clone.
                s_processMethod.Invoke(null, new object[] { clone });

                return clone;
            }
            catch (TargetInvocationException tie)
            {
                Debug.LogWarning($"[AvatarScope] MA build simulation failed: {tie.InnerException?.Message ?? tie.Message}");
                Cleanup(clone);
                return null;
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AvatarScope] MA build simulation failed: {e.Message}");
                Cleanup(clone);
                return null;
            }
        }

        public static void Cleanup(GameObject clone)
        {
            if (clone == null) return;
            try
            {
                UnityEngine.Object.DestroyImmediate(clone);
            }
            catch (Exception e)
            {
                Debug.LogWarning($"[AvatarScope] Cleanup failed: {e.Message}");
            }
        }

        /// <summary>
        /// Best-effort scan of the active scenes to remove any leftover temp clones from a previous run.
        /// </summary>
        public static void RemoveLingeringClones()
        {
            // Any GameObject whose name starts with "__AvatarScope_" is a temp build
            // artifact and should never persist in the user's scene.
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var s = SceneManager.GetSceneAt(i);
                if (!s.isLoaded) continue;
                foreach (var root in s.GetRootGameObjects())
                {
                    if (root != null && root.name != null && root.name.StartsWith("__AvatarScope_"))
                    {
                        UnityEngine.Object.DestroyImmediate(root);
                    }
                }
            }
        }
    }
}

using System.IO;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Estimates the contribution of a single asset to the final VRChat .vrca AssetBundle size.
    ///
    /// Approach (calibrated against real VRChat uploads):
    ///   - Texture: VRAM compressed size * crunch factor (~0.20 for crunched, ~0.85 for non-crunched).
    ///   - Mesh:    raw vertex/index data * 0.50 (LZ4 compresses mesh data well).
    ///   - AudioClip: raw file size (already compressed).
    ///   - Other:   raw file size * 0.70 (LZ4 on misc data).
    ///
    /// This is a STATISTICAL estimate based on typical VRChat avatar content.
    /// Real AssetBundle build (planned v0.3) would be exact but takes 10-60 seconds.
    /// </summary>
    public static class AssetSizeEstimator
    {
        private const double CrunchTextureFactor    = 0.20;
        private const double NonCrunchTextureFactor = 0.85;
        private const double MeshLZ4Factor          = 0.50;
        private const double OtherLZ4Factor         = 0.70;

        public struct AssetContribution
        {
            public long VRAMBytes;
            public long DownloadBytes;
            public long UncompressedBytes;   // bytes the AssetBundle holds for this asset before LZMA compression
        }

        public static AssetContribution Estimate(Object asset)
        {
            var c = new AssetContribution();
            if (asset == null) return c;

            // Skip source model/prefab containers - their useful contents
            // (Mesh, Texture, AnimationClip) are visited separately and counted accurately.
            // The container file itself never ships in the AssetBundle.
            if (asset is GameObject) return c;

            string path = AssetDatabase.GetAssetPath(asset);
            if (!string.IsNullOrEmpty(path))
            {
                string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
                if (IsSourceContainer(ext)) return c;
            }

            switch (asset)
            {
                case Texture tex:
                    c.VRAMBytes = TextureSizeCalculator.GetVRAMBytes(tex);
                    c.DownloadBytes = EstimateTextureDownload(tex, c.VRAMBytes);
                    // Uncompressed (in-bundle, pre-LZMA): roughly = VRAM (compressed GPU format)
                    // for non-crunched textures. For crunched, ~2x VRAM since crunch is an
                    // additional layer on top of BC formats.
                    c.UncompressedBytes = c.VRAMBytes;
                    return c;
                case Mesh mesh:
                    long meshRaw = EstimateMeshDataBytes(mesh);
                    c.DownloadBytes = (long)(meshRaw * MeshLZ4Factor);
                    c.UncompressedBytes = meshRaw;
                    return c;
                case AudioClip _:
                    long audioSize = GetFileSize(asset);
                    c.DownloadBytes = audioSize;
                    c.UncompressedBytes = audioSize;
                    return c;
                default:
                    long fileSize = GetFileSize(asset);
                    c.DownloadBytes = (long)(fileSize * OtherLZ4Factor);
                    c.UncompressedBytes = fileSize;
                    return c;
            }
        }

        private static bool IsSourceContainer(string ext)
        {
            switch (ext)
            {
                case ".fbx":
                case ".blend":
                case ".obj":
                case ".dae":
                case ".max":
                case ".ma":
                case ".mb":
                case ".3ds":
                case ".prefab":
                case ".psd":   // imported as Texture; source PSD itself doesn't ship
                case ".tiff":
                case ".tif":
                    return true;
                default:
                    return false;
            }
        }

        private static long EstimateTextureDownload(Texture tex, long vramBytes)
        {
            string path = AssetDatabase.GetAssetPath(tex);
            bool crunched = false;
            if (!string.IsNullOrEmpty(path))
            {
                var importer = AssetImporter.GetAtPath(path) as TextureImporter;
                if (importer != null)
                {
                    crunched = importer.crunchedCompression;
                }
            }
            double factor = crunched ? CrunchTextureFactor : NonCrunchTextureFactor;
            return (long)(vramBytes * factor);
        }

        /// <summary>
        /// Estimates the in-bundle uncompressed size of a Mesh based on vertex format and indices.
        /// Includes positions, normals, tangents, uv, bone weights, blendshapes, and triangles.
        /// </summary>
        public static long EstimateMeshDataBytes(Mesh mesh)
        {
            if (mesh == null) return 0;

            int vCount = mesh.vertexCount;
            long bytes = 0;

            // Position 3*4
            bytes += vCount * 12L;
            // Normal 3*4 (usually present)
            if (mesh.normals != null && mesh.normals.Length > 0) bytes += vCount * 12L;
            // Tangent 4*4
            if (mesh.tangents != null && mesh.tangents.Length > 0) bytes += vCount * 16L;
            // UV0 2*4
            if (mesh.uv != null && mesh.uv.Length > 0) bytes += vCount * 8L;
            // UV1-3 each 2*4 if present
            if (mesh.uv2 != null && mesh.uv2.Length > 0) bytes += vCount * 8L;
            if (mesh.uv3 != null && mesh.uv3.Length > 0) bytes += vCount * 8L;
            if (mesh.uv4 != null && mesh.uv4.Length > 0) bytes += vCount * 8L;
            // Colors 4*4
            if (mesh.colors != null && mesh.colors.Length > 0) bytes += vCount * 16L;
            // Bone weights 4 float + 4 int = 32 bytes per vertex
            if (mesh.boneWeights != null && mesh.boneWeights.Length > 0) bytes += vCount * 32L;

            // Indices
            int indexCount = 0;
            for (int i = 0; i < mesh.subMeshCount; i++)
                indexCount += (int)mesh.GetIndexCount(i);
            bytes += indexCount * (mesh.indexFormat == UnityEngine.Rendering.IndexFormat.UInt32 ? 4L : 2L);

            // BlendShapes: Unity stores deltas sparsely (only modified vertices, not all).
            // Real avatars typically have 10-20% of vertices modified per blendshape (a smile
            // only moves the mouth, not the legs). We use 15% as a realistic mean.
            // Per affected vertex: index (4) + vec3 pos + vec3 normal + vec3 tangent = 40 bytes.
            int bsCount = mesh.blendShapeCount;
            for (int i = 0; i < bsCount; i++)
            {
                int frames = mesh.GetBlendShapeFrameCount(i);
                bytes += (long)(frames * vCount * 40L * 0.15);
            }

            return bytes;
        }

        private static long GetFileSize(Object asset)
        {
            string path = AssetDatabase.GetAssetPath(asset);
            if (string.IsNullOrEmpty(path)) return 0;
            if (path.StartsWith("Library/") || path.StartsWith("Resources/unity_builtin")) return 0;
            try
            {
                var fi = new FileInfo(path);
                if (fi.Exists) return fi.Length;
            }
            catch { /* ignore */ }
            return 0;
        }
    }
}

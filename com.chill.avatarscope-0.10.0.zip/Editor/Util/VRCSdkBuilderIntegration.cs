using System;
using System.IO;
using System.Threading;
using UnityEditor;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDKBase.Editor;
using VRC.SDK3A.Editor;
#endif

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Invokes VRChat SDK's official public Build API to produce the exact same .vrca file
    /// VRChat would upload, then measures it. No upload occurs - just the build.
    ///
    /// API used: VRC.SDK3A.Editor.IVRCSdkAvatarBuilderApi.Build(GameObject) → Task<string>
    /// which is documented as a public API returning the path to the built bundle.
    /// </summary>
    public static class VRCSdkBuilderIntegration
    {
        public struct Result
        {
            public bool   Success;
            public long   BundleSizeBytes;
            public string MethodUsed;
            public string FailureReason;
        }

        // Allow at most this long for the SDK build to complete.
        private const int BuildTimeoutMs = 120_000;
        private const int PollIntervalMs = 50;

        public static Result TryBuildExact(GameObject avatar)
        {
            var r = new Result();
            if (avatar == null)
            {
                r.FailureReason = "avatar is null";
                return r;
            }

#if !AVATARSCOPE_HAS_VRCSDK
            r.FailureReason = "VRChat SDK not detected.";
            return r;
#else
            try
            {
                // The TryGetBuilder requires the SDK window to be open. Open it silently.
                EnsureSdkPanelOpen();

                if (!VRCSdkControlPanel.TryGetBuilder<IVRCSdkAvatarBuilderApi>(out var builder) || builder == null)
                {
                    r.FailureReason = "VRC SDK builder not available (panel may have failed to initialize).";
                    return r;
                }

                // Kick off the SDK's official Build API.
                var task = builder.Build(avatar);
                if (task == null)
                {
                    r.FailureReason = "builder.Build returned null Task.";
                    return r;
                }

                int waited = 0;
                while (!task.IsCompleted)
                {
                    Thread.Sleep(PollIntervalMs);
                    waited += PollIntervalMs;
                    if (waited > BuildTimeoutMs)
                    {
                        r.FailureReason = $"VRC SDK build timed out after {BuildTimeoutMs / 1000}s.";
                        return r;
                    }
                }

                if (task.IsFaulted)
                {
                    var inner = task.Exception?.GetBaseException();
                    r.FailureReason = $"VRC SDK build threw: {inner?.GetType().Name}: {inner?.Message}";
                    return r;
                }
                if (task.IsCanceled)
                {
                    r.FailureReason = "VRC SDK build was canceled.";
                    return r;
                }

                string path = task.Result;
                if (string.IsNullOrEmpty(path))
                {
                    r.FailureReason = "VRC SDK build returned empty path.";
                    return r;
                }
                if (!File.Exists(path))
                {
                    r.FailureReason = $"VRC SDK reported bundle path but file missing: {path}";
                    return r;
                }

                r.Success = true;
                r.BundleSizeBytes = new FileInfo(path).Length;
                r.MethodUsed = "VRC SDK IVRCSdkAvatarBuilderApi.Build";
                return r;
            }
            catch (Exception e)
            {
                r.FailureReason = $"{e.GetType().Name}: {e.Message}";
                return r;
            }
#endif
        }

#if AVATARSCOPE_HAS_VRCSDK
        private static void EnsureSdkPanelOpen()
        {
            if (VRCSdkControlPanel.window != null) return;
            // Opening as a utility window so it doesn't grab focus from AvatarScope.
            var w = EditorWindow.GetWindow<VRCSdkControlPanel>(utility: false, title: "VRChat SDK", focus: false);
            if (w != null)
            {
                // PopulateSdkBuilders runs lazily on first TryGetBuilder, no explicit call needed.
                w.Show();
            }
        }
#endif
    }
}

using System.Collections.Generic;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Analyzes how each texture is actually projected onto avatar geometry.
    /// Returns the maximum texel density (texels per world meter) used anywhere
    /// in the rendered mesh, which determines the minimum source resolution
    /// the GPU could possibly sample. Anything above that is wasted bandwidth.
    /// </summary>
    public static class UVDensityAnalyzer
    {
        public struct Report
        {
            public Texture2D Texture;
            public int       CurrentResolution;  // max(width, height)
            public int       OptimalResolution;  // recommended (power of 2)
            public double    MaxTexelsPerMeter;
            public bool      CanReduce;
            public double    CoveragePercent;    // % of UV space actually used
        }

        public static Report Analyze(Texture2D tex, GameObject avatar)
        {
            var r = new Report { Texture = tex };
            if (tex == null || avatar == null) return r;

            r.CurrentResolution = Mathf.Max(tex.width, tex.height);

            var materials = FindMaterialsUsing(tex, avatar);
            if (materials.Count == 0) return r;

            double maxTexelsPerMeter = 0;
            var uvUsed = new HashSet<(int, int)>(); // 32x32 UV bins for coverage estimate

            var renderers = avatar.GetComponentsInChildren<Renderer>(true);
            foreach (var rend in renderers)
            {
                if (rend == null) continue;
                Mesh mesh = MeshOf(rend);
                if (mesh == null) continue;

                var mats = rend.sharedMaterials;
                Vector3[] vertsLocal = mesh.vertices;
                Vector2[] uvs = mesh.uv;
                if (uvs == null || uvs.Length == 0) continue;

                // The transform of the renderer scales world-space measurements.
                Transform tr = rend.transform;

                for (int sm = 0; sm < mesh.subMeshCount && sm < mats.Length; sm++)
                {
                    if (!materials.Contains(mats[sm])) continue;
                    var sub = mesh.GetSubMesh(sm);
                    if (sub.topology != MeshTopology.Triangles) continue;

                    int[] indices = mesh.GetTriangles(sm);
                    for (int i = 0; i + 2 < indices.Length; i += 3)
                    {
                        int i0 = indices[i], i1 = indices[i + 1], i2 = indices[i + 2];
                        if (i0 >= uvs.Length || i1 >= uvs.Length || i2 >= uvs.Length) continue;

                        Vector3 w0 = tr.TransformPoint(vertsLocal[i0]);
                        Vector3 w1 = tr.TransformPoint(vertsLocal[i1]);
                        Vector3 w2 = tr.TransformPoint(vertsLocal[i2]);
                        double worldArea = TriangleArea(w0, w1, w2);
                        if (worldArea < 1e-8) continue;

                        Vector2 u0 = uvs[i0], u1 = uvs[i1], u2 = uvs[i2];
                        double uvArea = TriangleArea2D(u0, u1, u2);
                        if (uvArea < 1e-10) continue;

                        // texels covered by this triangle at current resolution
                        double texelsCovered = uvArea * tex.width * tex.height;
                        // density: texels per square meter
                        double densitySqM = texelsCovered / worldArea;
                        // sqrt to get linear density (texels per meter)
                        double linear = System.Math.Sqrt(densitySqM);
                        if (linear > maxTexelsPerMeter) maxTexelsPerMeter = linear;

                        // Coverage bins (sample center)
                        Vector2 centroid = (u0 + u1 + u2) / 3f;
                        int bx = Mathf.Clamp((int)(centroid.x * 32), 0, 31);
                        int by = Mathf.Clamp((int)(centroid.y * 32), 0, 31);
                        uvUsed.Add((bx, by));
                    }
                }
            }

            r.MaxTexelsPerMeter = maxTexelsPerMeter;
            r.CoveragePercent = uvUsed.Count / 1024.0 * 100.0;

            // Determine optimal resolution.
            // The current resolution provides (currentRes / max-mesh-extent) texels/m at the largest world face.
            // We want to keep at least the SAME max density (so quality is preserved).
            // Optimal source resolution = max linear density * max world extent of any single UV island
            //
            // Simplification: since maxTexelsPerMeter is already "linear texels per world meter at the
            // hot-spot triangle," we can express it as effective resolution.
            //
            // Effective resolution for the hottest triangle:
            //   effRes = sqrt(texelsInTriangle) (which we already have as sqrt(uvArea * res^2))
            //   = res * sqrt(uvArea)
            //
            // To preserve quality we keep that effRes intact. So the smallest source that still
            // delivers that effRes is: needed = ceil(effRes / sqrt(maxUvArea))
            // which equals current res IF the hottest triangle uses 100% UV. In practice it's much less.

            // Simpler & robust heuristic: scale resolution by sqrt(coverage)
            //   - if only 25% of UV is used, only need half the resolution
            //   - but also keep at least the current MAX texel density at the hot spot
            double coverage01 = uvUsed.Count / 1024.0;
            int byCoverage = (int)System.Math.Ceiling(r.CurrentResolution * System.Math.Sqrt(System.Math.Max(0.05, coverage01)));

            // Floor to next power of two (downward), but never below 128
            int rounded = NextPow2Down(byCoverage);
            rounded = Mathf.Clamp(rounded, 128, r.CurrentResolution);

            r.OptimalResolution = rounded;
            r.CanReduce = rounded < r.CurrentResolution;
            return r;
        }

        // ----- helpers -----

        private static Mesh MeshOf(Renderer r)
        {
            if (r is SkinnedMeshRenderer smr) return smr.sharedMesh;
            if (r is MeshRenderer && r.TryGetComponent<MeshFilter>(out var mf)) return mf.sharedMesh;
            return null;
        }

        private static HashSet<Material> FindMaterialsUsing(Texture2D tex, GameObject avatar)
        {
            var hits = new HashSet<Material>();
            var renderers = avatar.GetComponentsInChildren<Renderer>(true);
            foreach (var r in renderers)
            {
                if (r == null) continue;
                foreach (var m in r.sharedMaterials)
                {
                    if (m == null) continue;
                    if (MaterialUsesTexture(m, tex)) hits.Add(m);
                }
            }
            return hits;
        }

        private static bool MaterialUsesTexture(Material m, Texture2D tex)
        {
            if (m.shader == null) return false;
            int count = UnityEditor.ShaderUtil.GetPropertyCount(m.shader);
            for (int i = 0; i < count; i++)
            {
                if (UnityEditor.ShaderUtil.GetPropertyType(m.shader, i) != UnityEditor.ShaderUtil.ShaderPropertyType.TexEnv) continue;
                string name = UnityEditor.ShaderUtil.GetPropertyName(m.shader, i);
                if (m.GetTexture(name) == tex) return true;
            }
            return false;
        }

        private static double TriangleArea(Vector3 a, Vector3 b, Vector3 c)
        {
            return 0.5 * Vector3.Cross(b - a, c - a).magnitude;
        }

        private static double TriangleArea2D(Vector2 a, Vector2 b, Vector2 c)
        {
            return 0.5 * System.Math.Abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y));
        }

        private static int NextPow2Down(int v)
        {
            if (v <= 1) return 1;
            int p = 1;
            while (p * 2 <= v) p *= 2;
            return p;
        }
    }
}

using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
#endif

namespace Chill.AvatarScope.Editor.Util
{
    /// <summary>
    /// Detects BlendShapes on the avatar that are never referenced by any AnimationClip
    /// in any AnimatorController the avatar uses, including VRChat's expression / facial
    /// tracking shape lists. Anything not referenced is safe to strip — it cannot be
    /// activated at runtime.
    /// </summary>
    public static class BlendShapeUsageAnalyzer
    {
        public struct Report
        {
            public SkinnedMeshRenderer Renderer;
            public List<string> AllShapes;
            public List<string> UnusedShapes;
        }

        public static List<Report> Analyze(GameObject avatar)
        {
            var reports = new List<Report>();
            if (avatar == null) return reports;

            var usedShapes = CollectReferencedShapes(avatar);

            foreach (var smr in avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (smr == null || smr.sharedMesh == null) continue;
                int n = smr.sharedMesh.blendShapeCount;
                if (n == 0) continue;

                var all = new List<string>(n);
                var unused = new List<string>();
                string path = AnimationPathForRenderer(avatar, smr);
                for (int i = 0; i < n; i++)
                {
                    string name = smr.sharedMesh.GetBlendShapeName(i);
                    all.Add(name);
                    // Match key formats actually emitted by Animation: "{path}|{shapeName}"
                    string key = $"{path}|{name}";
                    string keyNoPath = $"|{name}"; // when the same shape name is used anywhere
                    if (!usedShapes.Contains(key) && !usedShapes.Contains(keyNoPath))
                    {
                        unused.Add(name);
                    }
                }

                reports.Add(new Report
                {
                    Renderer = smr,
                    AllShapes = all,
                    UnusedShapes = unused,
                });
            }
            return reports;
        }

        // ----- helpers -----

        private static HashSet<string> CollectReferencedShapes(GameObject avatar)
        {
            var set = new HashSet<string>();

            // 1. AnimatorControllers from any Animator on the avatar.
            foreach (var animator in avatar.GetComponentsInChildren<Animator>(true))
            {
                if (animator == null || animator.runtimeAnimatorController == null) continue;
                CollectFromController(animator.runtimeAnimatorController, set);
            }

#if AVATARSCOPE_HAS_VRCSDK
            // 2. VRC Avatar Descriptor playable layers.
            var desc = avatar.GetComponent<VRCAvatarDescriptor>();
            if (desc != null)
            {
                if (desc.baseAnimationLayers != null)
                {
                    foreach (var layer in desc.baseAnimationLayers)
                        if (layer.animatorController != null)
                            CollectFromController(layer.animatorController, set);
                }
                if (desc.specialAnimationLayers != null)
                {
                    foreach (var layer in desc.specialAnimationLayers)
                        if (layer.animatorController != null)
                            CollectFromController(layer.animatorController, set);
                }

                // 3. Viseme / Eyelid blendshape references.
                if (desc.lipSync == VRCAvatarDescriptor.LipSyncStyle.VisemeBlendShape
                    && desc.VisemeBlendShapes != null)
                {
                    foreach (var v in desc.VisemeBlendShapes)
                        if (!string.IsNullOrEmpty(v)) set.Add($"|{v}");
                }
                if (desc.customEyeLookSettings.eyelidType == VRCAvatarDescriptor.EyelidType.Blendshapes
                    && desc.customEyeLookSettings.eyelidsBlendshapes != null)
                {
                    foreach (var idx in desc.customEyeLookSettings.eyelidsBlendshapes)
                    {
                        // Index-based; record a wildcard so any shape on the eyelid mesh is considered used.
                        if (idx >= 0) set.Add("|<EYELID>");
                    }
                }
            }
#endif

            return set;
        }

        private static void CollectFromController(RuntimeAnimatorController rac, HashSet<string> output)
        {
            if (rac == null) return;
            if (rac.animationClips == null) return;
            foreach (var clip in rac.animationClips)
            {
                if (clip == null) continue;
                var bindings = AnimationUtility.GetCurveBindings(clip);
                foreach (var b in bindings)
                {
                    if (string.IsNullOrEmpty(b.propertyName)) continue;
                    const string prefix = "blendShape.";
                    if (!b.propertyName.StartsWith(prefix)) continue;
                    string shape = b.propertyName.Substring(prefix.Length);
                    output.Add($"{b.path}|{shape}");
                    output.Add($"|{shape}");
                }
            }
        }

        private static string AnimationPathForRenderer(GameObject avatar, Component target)
        {
            if (target.transform == avatar.transform) return string.Empty;
            return AnimationUtility.CalculateTransformPath(target.transform, avatar.transform);
        }
    }
}

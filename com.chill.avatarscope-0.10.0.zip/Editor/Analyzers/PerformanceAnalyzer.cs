using System.Collections.Generic;
using Chill.AvatarScope.Editor.Core;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Dynamics.PhysBone.Components;
using VRC.SDK3.Dynamics.Contact.Components;
#endif

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Counts the metrics that drive VRChat's Performance Rank.
    /// Polygons: triangle count of every Mesh referenced by SkinnedMeshRenderer / MeshFilter.
    /// Materials: distinct sharedMaterials across all renderers.
    /// PhysBones / Colliders / Contacts: component counts.
    /// Shader Keywords: distinct enabled keywords across all materials (proxy for shader variant cost).
    /// </summary>
    public static class PerformanceAnalyzer
    {
        public static void Analyze(GameObject avatar, MetricsResult result)
        {
            if (avatar == null) return;

            int polygons = 0;
            int materialSlots = 0;            // VRChat's "Material Slots" = sum of sharedMaterials.Length
            var keywordSet = new HashSet<string>();

            // SkinnedMeshRenderer
            var skinned = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in skinned)
            {
                if (smr == null) continue;
                if (smr.sharedMesh != null)
                {
                    polygons += CountTriangles(smr.sharedMesh);
                }
                materialSlots += CountAndAccumulateMaterials(smr.sharedMaterials, keywordSet);
            }

            // MeshFilter (static geometry)
            var meshFilters = avatar.GetComponentsInChildren<MeshFilter>(true);
            foreach (var mf in meshFilters)
            {
                if (mf == null) continue;
                if (mf.sharedMesh != null)
                {
                    polygons += CountTriangles(mf.sharedMesh);
                }
                var mr = mf.GetComponent<MeshRenderer>();
                if (mr != null)
                {
                    materialSlots += CountAndAccumulateMaterials(mr.sharedMaterials, keywordSet);
                }
            }

            result.Polygons = polygons;
            result.Materials = materialSlots;
            result.ShaderKeywords = keywordSet.Count;

            // PhysBones / Colliders / Contacts
#if AVATARSCOPE_HAS_VRCSDK
            result.PhysBones = avatar.GetComponentsInChildren<VRCPhysBone>(true).Length;
            result.Colliders = avatar.GetComponentsInChildren<VRCPhysBoneCollider>(true).Length;
            // Contacts are counted but not stored here; CompatibilityChecker may use them later.
#else
            result.PhysBones = 0;
            result.Colliders = 0;
#endif
        }

        private static int CountTriangles(Mesh mesh)
        {
            int total = 0;
            int subCount = mesh.subMeshCount;
            for (int i = 0; i < subCount; i++)
            {
                var sm = mesh.GetSubMesh(i);
                // indexCount is points/lines/tris depending on topology, but for triangle topology it's tri-vertices.
                if (sm.topology == MeshTopology.Triangles)
                    total += sm.indexCount / 3;
                else if (sm.topology == MeshTopology.Quads)
                    total += sm.indexCount / 4 * 2; // approx
            }
            return total;
        }

        /// <summary>
        /// Counts material slots (including duplicates / nulls) and accumulates shader keywords.
        /// Returns the slot count for this renderer (= sharedMaterials.Length, matching VRChat).
        /// </summary>
        private static int CountAndAccumulateMaterials(Material[] mats, HashSet<string> kwSet)
        {
            if (mats == null) return 0;
            int slots = mats.Length; // VRChat counts slots, including null and duplicate slots
            foreach (var m in mats)
            {
                if (m == null) continue;
                var kws = m.shaderKeywords;
                if (kws != null)
                {
                    foreach (var k in kws)
                    {
                        if (!string.IsNullOrEmpty(k)) kwSet.Add(k);
                    }
                }
            }
            return slots;
        }
    }
}

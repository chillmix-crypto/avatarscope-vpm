using System.Collections.Generic;
using Chill.AvatarScope.Editor.Core;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Avatars.Components;
#endif

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Checks PC upload eligibility, Quest compatibility, Fallback eligibility, and Face Tracking readiness.
    /// </summary>
    public static class CompatibilityChecker
    {
        // VRChat's Quest-allowed shader prefixes.
        private static readonly string[] QuestAllowedShaderPrefixes =
        {
            "VRChat/Mobile/",
            "VRChat/Mobile",
        };

        // ARKit 52 blendshape names used by VRChat's native face tracking integration.
        private static readonly string[] ArkitShapeNames =
        {
            "jawOpen", "jawForward", "jawLeft", "jawRight",
            "eyeBlinkLeft", "eyeBlinkRight", "eyeLookUpLeft", "eyeLookUpRight",
            "eyeLookDownLeft", "eyeLookDownRight", "eyeLookInLeft", "eyeLookInRight",
            "eyeLookOutLeft", "eyeLookOutRight",
            "browInnerUp", "browDownLeft", "browDownRight",
            "browOuterUpLeft", "browOuterUpRight",
            "cheekPuff", "cheekSquintLeft", "cheekSquintRight",
            "mouthClose", "mouthFunnel", "mouthPucker", "mouthLeft", "mouthRight",
            "mouthSmileLeft", "mouthSmileRight", "mouthFrownLeft", "mouthFrownRight",
            "mouthDimpleLeft", "mouthDimpleRight", "mouthStretchLeft", "mouthStretchRight",
            "mouthRollLower", "mouthRollUpper", "mouthShrugLower", "mouthShrugUpper",
            "mouthPressLeft", "mouthPressRight", "mouthLowerDownLeft", "mouthLowerDownRight",
            "mouthUpperUpLeft", "mouthUpperUpRight",
            "noseSneerLeft", "noseSneerRight",
            "tongueOut",
        };

        public static void Analyze(GameObject avatar, MetricsResult result)
        {
            if (avatar == null) return;

            CheckPC(avatar, result);
            CheckQuest(avatar, result);
            CheckFallback(avatar, result);
            CheckFacetra(avatar, result);
        }

        private static void CheckPC(GameObject avatar, MetricsResult result)
        {
            var problems = new List<string>();

#if AVATARSCOPE_HAS_VRCSDK
            var desc = avatar.GetComponent<VRCAvatarDescriptor>();
            if (desc == null)
                problems.Add("No VRCAvatarDescriptor");
#endif
            if (result.ParamBitsUsed > result.ParamBitsMax)
                problems.Add($"Parameters over limit ({result.ParamBitsUsed}/{result.ParamBitsMax} bit)");

            result.PCUploadOK = problems.Count == 0;
            result.PCUploadMessage = result.PCUploadOK ? "OK" : string.Join(" / ", problems);
        }

        private static void CheckQuest(GameObject avatar, MetricsResult result)
        {
            var renderers = avatar.GetComponentsInChildren<Renderer>(true);
            var disallowedShaders = new HashSet<string>();

            foreach (var r in renderers)
            {
                if (r == null) continue;
                foreach (var m in r.sharedMaterials)
                {
                    if (m == null || m.shader == null) continue;
                    if (!IsQuestAllowed(m.shader.name))
                    {
                        disallowedShaders.Add(m.shader.name);
                    }
                }
            }

            if (disallowedShaders.Count == 0)
            {
                result.QuestCompatible = true;
                result.QuestMessage = "OK (all shaders mobile-compatible)";
            }
            else
            {
                result.QuestCompatible = false;
                int show = System.Math.Min(2, disallowedShaders.Count);
                var preview = new List<string>(show);
                int n = 0;
                foreach (var s in disallowedShaders)
                {
                    preview.Add(s);
                    if (++n >= show) break;
                }
                string extra = disallowedShaders.Count > show ? $" +{disallowedShaders.Count - show} more" : "";
                result.QuestMessage = $"Disallowed: {string.Join(", ", preview)}{extra}";
            }
        }

        private static bool IsQuestAllowed(string shaderName)
        {
            if (string.IsNullOrEmpty(shaderName)) return false;
            foreach (var prefix in QuestAllowedShaderPrefixes)
            {
                if (shaderName.StartsWith(prefix)) return true;
            }
            return false;
        }

        private static void CheckFallback(GameObject avatar, MetricsResult result)
        {
            // Fallback requirements (VRChat): Good or better rank, single Skinned Mesh, etc.
            // We approximate by polygon and material thresholds.
            bool polyOk = result.Polygons <= 32000;
            bool matOk  = result.Materials <= 4;
            bool sizeOk = result.DownloadEstimateBytes <= 10L * 1024 * 1024; // 10 MB

            if (polyOk && matOk && sizeOk)
            {
                result.FallbackEligible = true;
                result.FallbackMessage = "Likely eligible (Good rank or better)";
            }
            else
            {
                result.FallbackEligible = false;
                var problems = new List<string>();
                if (!polyOk) problems.Add($"polys {result.Polygons} > 32000");
                if (!matOk)  problems.Add($"materials {result.Materials} > 4");
                if (!sizeOk) problems.Add("download estimate > 10 MB");
                result.FallbackMessage = "Not eligible: " + string.Join(", ", problems);
            }
        }

        private static void CheckFacetra(GameObject avatar, MetricsResult result)
        {
            var found = new HashSet<string>();
            var skinned = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in skinned)
            {
                if (smr == null || smr.sharedMesh == null) continue;
                int n = smr.sharedMesh.blendShapeCount;
                for (int i = 0; i < n; i++)
                {
                    var name = smr.sharedMesh.GetBlendShapeName(i);
                    foreach (var ark in ArkitShapeNames)
                    {
                        if (name.IndexOf(ark, System.StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            found.Add(ark);
                        }
                    }
                }
            }

            if (found.Count == 0)
            {
                result.FacetraReady = false;
                result.FacetraMessage = "No ARKit shapes detected";
            }
            else if (found.Count < 20)
            {
                result.FacetraReady = false;
                result.FacetraMessage = $"Partial ({found.Count}/{ArkitShapeNames.Length} ARKit shapes)";
            }
            else
            {
                result.FacetraReady = true;
                result.FacetraMessage = $"Ready ({found.Count}/{ArkitShapeNames.Length} ARKit shapes)";
            }
        }
    }
}

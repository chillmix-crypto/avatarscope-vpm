using Chill.AvatarScope.Editor.Core;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDKBase.Validation.Performance;
using VRC.SDKBase.Validation.Performance.Stats;
#endif

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Mirrors VRChat's Avatar Performance panel. Every metric is collected from VRC SDK's
    /// AvatarPerformanceStats and ranked using the same thresholds VRChat publishes.
    /// Field labels are matched to the official Japanese VRChat UI for easy cross-reference.
    /// </summary>
    public static class PerformanceRankAnalyzer
    {
        public static void Analyze(GameObject avatar, MetricsResult result)
        {
            if (avatar == null) return;

#if AVATARSCOPE_HAS_VRCSDK
            var pc = ComputeStats(avatar, isMobile: false);
            var q  = ComputeStats(avatar, isMobile: true);

            if (pc != null)
            {
                FillBaseStats(pc, result);
                ApplyRanks(pc, isMobile: false, result.PerCategoryPC);
                result.RankPC = WorstRank(result.PerCategoryPC);
            }
            if (q != null)
            {
                ApplyRanks(q, isMobile: true, result.PerCategoryQuest);
                result.RankQuest = WorstRank(result.PerCategoryQuest);
            }
#endif
        }

#if AVATARSCOPE_HAS_VRCSDK
        private static AvatarPerformanceStats ComputeStats(GameObject avatar, bool isMobile)
        {
            var stats = new AvatarPerformanceStats(isMobile);
            try { AvatarPerformance.CalculatePerformanceStats(avatar.name, avatar, stats, isMobile); }
            catch (System.Exception e)
            {
                Debug.LogWarning($"[AvatarScope] Performance stats failed ({(isMobile?"Quest":"PC")}): {e.Message}");
                return null;
            }
            return stats;
        }

        private static void FillBaseStats(AvatarPerformanceStats s, MetricsResult r)
        {
            r.Polygons              = SafeInt(s.polyCount);
            r.Materials             = SafeInt(s.materialCount);
            r.SkinnedMeshes         = SafeInt(s.skinnedMeshCount);
            r.Meshes                = SafeInt(s.meshCount);
            r.Animators             = SafeInt(s.animatorCount);
            r.Bones                 = SafeInt(s.boneCount);
            r.Lights                = SafeInt(s.lightCount);
            r.ParticleSystems       = SafeInt(s.particleSystemCount);
            r.ParticleMaxTotal      = SafeInt(s.particleTotalCount);
            r.ParticleMeshPolygons  = SafeInt(s.particleMaxMeshPolyCount);
            r.ParticleTrails        = s.particleTrailsEnabled.GetValueOrDefault();
            r.ParticleCollision     = s.particleCollisionEnabled.GetValueOrDefault();
            r.TrailRenderers        = SafeInt(s.trailRendererCount);
            r.LineRenderers         = SafeInt(s.lineRendererCount);
            r.ClothMeshes           = SafeInt(s.clothCount);
            r.ClothMaxVertices      = SafeInt(s.clothMaxVertices);
            r.PhysicsColliders      = SafeInt(s.physicsColliderCount);
            r.PhysicsRigidbodies    = SafeInt(s.physicsRigidbodyCount);
            r.AudioSources          = SafeInt(s.audioSourceCount);

            // Newer SDK fields (may not exist in older SDKs).
            r.Contacts = TryReadInt(s, "contactCount");
            r.Constraints = TryReadInt(s, "constraintsCount");
            if (r.Constraints == 0) r.Constraints = TryReadInt(s, "constraintCount");
            r.ConstraintDepth = TryReadInt(s, "constraintDepth");

            if (s.physBone.HasValue)
            {
                var pb = s.physBone.Value;
                r.PhysBones               = SafeInt(pb.componentCount);
                r.Colliders               = SafeInt(pb.colliderCount);
                r.PhysBoneTransforms      = SafeInt(pb.transformCount);
                r.PhysBoneCollisionChecks = SafeInt(pb.collisionCheckCount);
            }

            // Bounds
            if (s.aabb.HasValue) r.BoundsSize = s.aabb.Value.size;

            // NOTE: We intentionally do NOT read "uncompressedSize" from the SDK.
            // The field name / semantics have shifted across SDK versions and have produced
            // extreme overestimates (5 GB+) in the wild. SizeAnalyzer's own calculation
            // (sum of VRAM + mesh data + others) is more consistent.
        }

        private static void ApplyRanks(AvatarPerformanceStats s, bool isMobile,
            System.Collections.Generic.Dictionary<string, MetricsResult.VRCRank> output)
        {
            var t = isMobile ? Quest : PC;

            output["PolyCount"]                  = RankFor(SafeInt(s.polyCount), t.Polys);
            output["MaterialCount"]              = RankFor(SafeInt(s.materialCount), t.Materials);
            output["SkinnedMeshCount"]           = RankFor(SafeInt(s.skinnedMeshCount), t.SkinnedMeshes);
            output["MeshCount"]                  = RankFor(SafeInt(s.meshCount), t.Meshes);
            output["AnimatorCount"]              = RankFor(SafeInt(s.animatorCount), t.Animators);
            output["BoneCount"]                  = RankFor(SafeInt(s.boneCount), t.Bones);
            output["LightCount"]                 = RankFor(SafeInt(s.lightCount), t.Lights);
            output["ParticleSystemCount"]        = RankFor(SafeInt(s.particleSystemCount), t.ParticleSystems);
            output["ParticleTotalCount"]         = RankFor(SafeInt(s.particleTotalCount), t.ParticleTotal);
            output["ParticleMeshPolyCount"]      = RankFor(SafeInt(s.particleMaxMeshPolyCount), t.ParticleMeshPoly);
            output["ParticleTrails"]             = RankForBool(s.particleTrailsEnabled.GetValueOrDefault(), t.ParticleTrails);
            output["ParticleCollision"]          = RankForBool(s.particleCollisionEnabled.GetValueOrDefault(), t.ParticleCollision);
            output["TrailRendererCount"]         = RankFor(SafeInt(s.trailRendererCount), t.TrailRenderers);
            output["LineRendererCount"]          = RankFor(SafeInt(s.lineRendererCount), t.LineRenderers);
            output["ClothCount"]                 = RankFor(SafeInt(s.clothCount), t.Cloth);
            output["ClothMaxVertices"]           = RankFor(SafeInt(s.clothMaxVertices), t.ClothVertices);
            output["PhysicsColliderCount"]       = RankFor(SafeInt(s.physicsColliderCount), t.PhysicsColliders);
            output["PhysicsRigidbodyCount"]      = RankFor(SafeInt(s.physicsRigidbodyCount), t.PhysicsRigidbodies);
            output["AudioSourceCount"]           = RankFor(SafeInt(s.audioSourceCount), t.AudioSources);

            int contacts = TryReadInt(s, "contactCount");
            output["ContactCount"]               = RankFor(contacts, t.Contacts);

            int constraints = TryReadInt(s, "constraintsCount");
            if (constraints == 0) constraints = TryReadInt(s, "constraintCount");
            output["ConstraintCount"]            = RankFor(constraints, t.Constraints);

            int depth = TryReadInt(s, "constraintDepth");
            output["ConstraintDepth"]            = RankFor(depth, t.ConstraintDepth);

            if (s.physBone.HasValue)
            {
                var pb = s.physBone.Value;
                output["PhysBoneComponentCount"]      = RankFor(SafeInt(pb.componentCount), t.PhysBoneComponents);
                output["PhysBoneTransformCount"]      = RankFor(SafeInt(pb.transformCount), t.PhysBoneTransforms);
                output["PhysBoneColliderCount"]       = RankFor(SafeInt(pb.colliderCount), t.PhysBoneColliders);
                output["PhysBoneCollisionCheckCount"] = RankFor(SafeInt(pb.collisionCheckCount), t.PhysBoneCollisionChecks);
            }
        }
#endif

        // ===== Thresholds (matching VRChat Performance Rank tables) =====
        private struct Thresholds
        {
            public int[] Polys;
            public int[] Materials;
            public int[] SkinnedMeshes;
            public int[] Meshes;
            public int[] Animators;
            public int[] Bones;
            public int[] Lights;
            public int[] ParticleSystems;
            public int[] ParticleTotal;
            public int[] ParticleMeshPoly;
            public bool[] ParticleTrails;
            public bool[] ParticleCollision;
            public int[] TrailRenderers;
            public int[] LineRenderers;
            public int[] Cloth;
            public int[] ClothVertices;
            public int[] PhysicsColliders;
            public int[] PhysicsRigidbodies;
            public int[] AudioSources;
            public int[] Contacts;
            public int[] Constraints;
            public int[] ConstraintDepth;
            public int[] PhysBoneComponents;
            public int[] PhysBoneTransforms;
            public int[] PhysBoneColliders;
            public int[] PhysBoneCollisionChecks;
        }

        // PC (Standalone Windows) — [Excellent, Good, Medium, Poor]
        private static readonly Thresholds PC = new Thresholds
        {
            Polys                  = new[] { 32000, 70000, 70000, 70000 },
            Materials              = new[] { 4, 8, 16, 32 },
            SkinnedMeshes          = new[] { 1, 2, 8, 16 },
            Meshes                 = new[] { 4, 8, 16, 24 },
            Animators              = new[] { 1, 1, 1, 1 },
            Bones                  = new[] { 75, 150, 256, 400 },
            Lights                 = new[] { 0, 0, 1, 4 },
            ParticleSystems        = new[] { 0, 4, 8, 16 },
            ParticleTotal          = new[] { 0, 200, 1000, 2500 },
            ParticleMeshPoly       = new[] { 0, 500, 2500, 5000 },
            ParticleTrails         = new[] { false, false, true, true },
            ParticleCollision      = new[] { false, false, true, true },
            TrailRenderers         = new[] { 0, 1, 4, 8 },
            LineRenderers          = new[] { 0, 2, 4, 8 },
            Cloth                  = new[] { 0, 1, 1, 1 },
            ClothVertices          = new[] { 0, 100, 200, 200 },
            PhysicsColliders       = new[] { 0, 2, 4, 8 },
            PhysicsRigidbodies     = new[] { 0, 1, 4, 8 },
            AudioSources           = new[] { 0, 4, 8, 16 },
            Contacts               = new[] { 4, 8, 16, 32 },
            Constraints            = new[] { 5, 25, 75, 350 },
            ConstraintDepth        = new[] { 1, 4, 30, 100 },
            PhysBoneComponents     = new[] { 4, 8, 16, 32 },
            PhysBoneTransforms     = new[] { 32, 64, 128, 256 },
            PhysBoneColliders      = new[] { 4, 8, 16, 32 },
            PhysBoneCollisionChecks= new[] { 16, 32, 64, 512 },
        };

        // Quest (Android) — much stricter
        private static readonly Thresholds Quest = new Thresholds
        {
            Polys                  = new[] { 7500, 10000, 15000, 20000 },
            Materials              = new[] { 1, 2, 2, 4 },
            SkinnedMeshes          = new[] { 1, 1, 2, 2 },
            Meshes                 = new[] { 1, 1, 1, 2 },
            Animators              = new[] { 1, 1, 1, 1 },
            Bones                  = new[] { 75, 100, 150, 200 },
            Lights                 = new[] { 0, 0, 0, 1 },
            ParticleSystems        = new[] { 0, 2, 4, 8 },
            ParticleTotal          = new[] { 0, 100, 400, 1000 },
            ParticleMeshPoly       = new[] { 0, 250, 1000, 2000 },
            ParticleTrails         = new[] { false, false, true, true },
            ParticleCollision      = new[] { false, false, true, true },
            TrailRenderers         = new[] { 0, 1, 2, 4 },
            LineRenderers          = new[] { 0, 1, 2, 4 },
            Cloth                  = new[] { 0, 0, 1, 1 },
            ClothVertices          = new[] { 0, 0, 100, 100 },
            PhysicsColliders       = new[] { 0, 2, 8, 16 },
            PhysicsRigidbodies     = new[] { 0, 1, 2, 8 },
            AudioSources           = new[] { 0, 2, 4, 8 },
            Contacts               = new[] { 0, 4, 8, 16 },
            Constraints            = new[] { 0, 10, 30, 100 },
            ConstraintDepth        = new[] { 1, 4, 30, 100 },
            PhysBoneComponents     = new[] { 0, 4, 8, 16 },
            PhysBoneTransforms     = new[] { 0, 16, 32, 64 },
            PhysBoneColliders      = new[] { 0, 4, 8, 16 },
            PhysBoneCollisionChecks= new[] { 0, 8, 16, 32 },
        };

        private static MetricsResult.VRCRank RankFor(int value, int[] limits)
        {
            if (limits == null || limits.Length < 4) return MetricsResult.VRCRank.None;
            if (value <= limits[0]) return MetricsResult.VRCRank.Excellent;
            if (value <= limits[1]) return MetricsResult.VRCRank.Good;
            if (value <= limits[2]) return MetricsResult.VRCRank.Medium;
            if (value <= limits[3]) return MetricsResult.VRCRank.Poor;
            return MetricsResult.VRCRank.VeryPoor;
        }

        private static MetricsResult.VRCRank RankForBool(bool value, bool[] limits)
        {
            // For boolean stats, find the lowest rank that still permits this value.
            if (limits == null || limits.Length < 4) return MetricsResult.VRCRank.None;
            for (int i = 0; i < 4; i++)
            {
                if (value == limits[i] || (limits[i] && !value))
                    return (MetricsResult.VRCRank)(i + 1); // Excellent..Poor
            }
            return MetricsResult.VRCRank.VeryPoor;
        }

        private static MetricsResult.VRCRank WorstRank(System.Collections.Generic.Dictionary<string, MetricsResult.VRCRank> ranks)
        {
            var worst = MetricsResult.VRCRank.Excellent;
            foreach (var kv in ranks)
            {
                if ((int)kv.Value > (int)worst) worst = kv.Value;
            }
            return worst;
        }

        private static int SafeInt(int v) => v;
        private static int SafeInt(long v) => (int)System.Math.Min(int.MaxValue, v);
        private static int SafeInt(int? v) => v ?? 0;
        private static int SafeInt(long? v) => v.HasValue ? (int)System.Math.Min(int.MaxValue, v.Value) : 0;
        private static int SafeInt(uint? v) => v.HasValue ? (int)System.Math.Min(int.MaxValue, v.Value) : 0;

        // Reflection-based reads for fields that may not exist on older SDK versions.
        // Note: boxed Nullable<T> values unwrap to T (or null), so we only need the T patterns.
        private static int TryReadInt(object obj, string fieldName)
        {
            try
            {
                var t = obj.GetType();
                var f = t.GetField(fieldName);
                if (f == null) return 0;
                var v = f.GetValue(obj);
                if (v == null) return 0;
                if (v is int vi)  return vi;
                if (v is long vl) return (int)System.Math.Min(int.MaxValue, vl);
                if (v is uint vu) return (int)vu;
            }
            catch { }
            return 0;
        }

        private static long TryReadLong(object obj, string fieldName)
        {
            try
            {
                var t = obj.GetType();
                var f = t.GetField(fieldName);
                if (f == null) return 0;
                var v = f.GetValue(obj);
                if (v == null) return 0;
                if (v is long vl) return vl;
                if (v is int vi)  return vi;
                if (v is uint vu) return vu;
            }
            catch { }
            return 0;
        }
    }
}

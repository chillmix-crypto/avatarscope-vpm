using System.Collections.Generic;
using System.IO;
using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Dynamics.PhysBone.Components;
#endif

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Builds the tree-view breakdown items in both GameObject and Asset view modes.
    /// GameObject view: walks the hierarchy, computing per-subtree weight.
    /// Asset view: groups by unique asset file, ranks by file size.
    /// </summary>
    public static class BreakdownBuilder
    {
        public static List<BreakdownItem> BuildGameObjectView(GameObject avatar)
        {
            var items = new List<BreakdownItem>();
            if (avatar == null) return items;

            // Top-level children are most useful: usually each child is a logical part (body, hair, outfit, ...).
            foreach (Transform child in avatar.transform)
            {
                items.Add(BuildGameObjectItem(child.gameObject, 0));
            }

            return items;
        }

        private static BreakdownItem BuildGameObjectItem(GameObject go, int depth)
        {
            var item = new BreakdownItem
            {
                Name = go.name,
                UnityObject = go,
                Depth = depth,
            };

            var (file, vram) = SizeAnalyzer.AnalyzeSubtree(go);
            item.FileSizeBytes = file;
            item.VRAMBytes = vram;

            int poly = 0;
            int mats = 0;
            var matSet = new HashSet<Material>();

            var renderers = go.GetComponentsInChildren<Renderer>(true);
            foreach (var r in renderers)
            {
                if (r is SkinnedMeshRenderer smr && smr.sharedMesh != null)
                    poly += smr.sharedMesh.triangles.Length / 3;
                if (r is MeshRenderer && r.TryGetComponent<MeshFilter>(out var mf) && mf.sharedMesh != null)
                    poly += mf.sharedMesh.triangles.Length / 3;

                foreach (var m in r.sharedMaterials)
                {
                    if (m != null) matSet.Add(m);
                }
            }
            mats = matSet.Count;

#if AVATARSCOPE_HAS_VRCSDK
            int pb = go.GetComponentsInChildren<VRCPhysBone>(true).Length;
            int col = go.GetComponentsInChildren<VRCPhysBoneCollider>(true).Length;
            item.PhysBones = pb;
            item.Colliders = col;
#endif
            item.Polygons = poly;
            item.Materials = mats;

            // Recurse one level for child grouping (don't explode entire hierarchy).
            if (depth < 2 && go.transform.childCount > 0 && go.transform.childCount <= 30)
            {
                foreach (Transform c in go.transform)
                {
                    var child = BuildGameObjectItem(c.gameObject, depth + 1);
                    // Only nest children that carry weight.
                    if (child.FileSizeBytes > 0 || child.Polygons > 0)
                        item.Children.Add(child);
                }
            }

            return item;
        }

        public static List<BreakdownItem> BuildAssetView(GameObject avatar)
        {
            var items = new List<BreakdownItem>();
            if (avatar == null) return items;

            // Group: one row per top-level dependency asset (fbx, png, mat, etc.).
            var topAssets = new Dictionary<string, BreakdownItem>();
            var visited = new HashSet<Object>();

            var components = avatar.GetComponentsInChildren<Component>(true);
            foreach (var comp in components)
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null) continue;
                    CollectAsset(obj, visited, topAssets);
                }
            }

            items.AddRange(topAssets.Values);
            return items;
        }

        private static void CollectAsset(Object obj, HashSet<Object> visited, Dictionary<string, BreakdownItem> topAssets)
        {
            if (obj == null || visited.Contains(obj)) return;
            visited.Add(obj);

            string path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) return;
            if (path.StartsWith("Library/") || path.StartsWith("Resources/unity_builtin")) return;

            // Use the same estimate as the summary so totals match.
            var contrib = AssetSizeEstimator.Estimate(obj);

            if (!topAssets.TryGetValue(path, out var item))
            {
                item = new BreakdownItem
                {
                    Name = Path.GetFileName(path),
                    UnityObject = obj,
                    FileSizeBytes = contrib.DownloadBytes,
                    VRAMBytes = contrib.VRAMBytes,
                };
                topAssets[path] = item;
            }
            else
            {
                if (item.VRAMBytes == 0 && contrib.VRAMBytes > 0) item.VRAMBytes = contrib.VRAMBytes;
            }

            // Recurse into asset dependencies (texture inside a material, etc.) as children
            var deps = AssetDatabase.GetDependencies(path, false);
            foreach (var depPath in deps)
            {
                if (depPath == path) continue;
                var depObj = AssetDatabase.LoadMainAssetAtPath(depPath);
                if (depObj == null) continue;
                if (visited.Contains(depObj)) continue;
                visited.Add(depObj);

                var depContrib = AssetSizeEstimator.Estimate(depObj);

                item.Children.Add(new BreakdownItem
                {
                    Name = Path.GetFileName(depPath),
                    UnityObject = depObj,
                    FileSizeBytes = depContrib.DownloadBytes,
                    VRAMBytes = depContrib.VRAMBytes,
                    Depth = 1,
                });
            }
        }

        public static void Sort(List<BreakdownItem> items, BreakdownSortMode mode)
        {
            items.Sort((a, b) => Compare(b, a, mode)); // descending
            foreach (var it in items)
            {
                if (it.Children != null && it.Children.Count > 0)
                    Sort(it.Children, mode);
            }
        }

        private static int Compare(BreakdownItem a, BreakdownItem b, BreakdownSortMode mode)
        {
            switch (mode)
            {
                case BreakdownSortMode.FileSize:  return a.FileSizeBytes.CompareTo(b.FileSizeBytes);
                case BreakdownSortMode.VRAM:      return a.VRAMBytes.CompareTo(b.VRAMBytes);
                case BreakdownSortMode.Polygons:  return a.Polygons.CompareTo(b.Polygons);
                case BreakdownSortMode.PhysBones: return a.PhysBones.CompareTo(b.PhysBones);
            }
            return 0;
        }
    }
}

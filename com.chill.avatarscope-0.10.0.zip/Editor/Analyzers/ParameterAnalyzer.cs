using Chill.AvatarScope.Editor.Core;
using UnityEngine;

#if AVATARSCOPE_HAS_VRCSDK
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
#endif

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Calculates the Expression Parameter bit usage exactly as VRChat does.
    /// Bool  = 1 bit, Int = 8 bit, Float = 8 bit.
    /// 16 bits are pre-reserved by VRChat itself; the user budget is 256 - 16 = 240 by default,
    /// but VRCExpressionParameters.MAX_PARAMETER_COST already reflects the current SDK value.
    /// </summary>
    public static class ParameterAnalyzer
    {
        public static void Analyze(GameObject avatar, MetricsResult result)
        {
            if (avatar == null) return;

#if AVATARSCOPE_HAS_VRCSDK
            var desc = avatar.GetComponent<VRCAvatarDescriptor>();
            if (desc == null) return;

            var ep = desc.expressionParameters;
            if (ep == null)
            {
                result.ParamBitsUsed = 0;
                result.ParamBitsMax = VRCExpressionParameters.MAX_PARAMETER_COST;
                return;
            }

            result.ParamBitsUsed = ep.CalcTotalCost();
            result.ParamBitsMax = VRCExpressionParameters.MAX_PARAMETER_COST;

            int b = 0, i = 0, f = 0;
            if (ep.parameters != null)
            {
                foreach (var p in ep.parameters)
                {
                    if (p == null) continue;
                    switch (p.valueType)
                    {
                        case VRCExpressionParameters.ValueType.Bool:  b++; break;
                        case VRCExpressionParameters.ValueType.Int:   i++; break;
                        case VRCExpressionParameters.ValueType.Float: f++; break;
                    }
                }
            }
            result.ParamCountBool  = b;
            result.ParamCountInt   = i;
            result.ParamCountFloat = f;
#endif
        }
    }
}

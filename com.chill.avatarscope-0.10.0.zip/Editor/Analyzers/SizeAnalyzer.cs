using System.Collections.Generic;
using Chill.AvatarScope.Editor.Core;
using Chill.AvatarScope.Editor.Util;
using UnityEditor;
using UnityEngine;

namespace Chill.AvatarScope.Editor.Analyzers
{
    /// <summary>
    /// Calculates download size (.vrca AssetBundle estimate) and VRAM usage for the avatar.
    /// Each unique referenced asset is counted once. See AssetSizeEstimator for the per-asset model.
    /// </summary>
    public static class SizeAnalyzer
    {
        public static void Analyze(GameObject avatar, MetricsResult result)
        {
            if (avatar == null) return;

            var visited = new HashSet<Object>();
            long downloadBytes = 0;
            long vramBytes = 0;
            long uncompressedBytes = 0;

            var components = avatar.GetComponentsInChildren<Component>(true);
            foreach (var comp in components)
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null) continue;
                    AccumulateAsset(obj, visited, ref downloadBytes, ref vramBytes, ref uncompressedBytes);
                }
            }

            var smrs = avatar.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in smrs)
            {
                if (smr == null || smr.sharedMesh == null) continue;
                AccumulateAsset(smr.sharedMesh, visited, ref downloadBytes, ref vramBytes, ref uncompressedBytes);
            }
            var mfs = avatar.GetComponentsInChildren<MeshFilter>(true);
            foreach (var mf in mfs)
            {
                if (mf == null || mf.sharedMesh == null) continue;
                AccumulateAsset(mf.sharedMesh, visited, ref downloadBytes, ref vramBytes, ref uncompressedBytes);
            }

            result.DownloadEstimateBytes = downloadBytes;
            result.UploadEstimateBytes   = downloadBytes;
            result.VRAMEstimateBytes     = vramBytes;
            // Only set if PerformanceRankAnalyzer didn't fill an SDK-provided value.
            if (result.UncompressedBytes == 0)
                result.UncompressedBytes = uncompressedBytes;
        }

        private static void AccumulateAsset(Object obj, HashSet<Object> visited, ref long downloadBytes, ref long vramBytes, ref long uncompressedBytes)
        {
            if (obj == null || visited.Contains(obj)) return;
            visited.Add(obj);

            var c = AssetSizeEstimator.Estimate(obj);
            downloadBytes     += c.DownloadBytes;
            vramBytes         += c.VRAMBytes;
            uncompressedBytes += c.UncompressedBytes;

            // Recurse dependencies (materials -> textures, prefabs -> meshes, etc.)
            string path = AssetDatabase.GetAssetPath(obj);
            if (string.IsNullOrEmpty(path)) return;
            if (path.StartsWith("Library/") || path.StartsWith("Resources/unity_builtin")) return;

            var deps = AssetDatabase.GetDependencies(path, false);
            foreach (var depPath in deps)
            {
                if (depPath == path) continue;
                var depObj = AssetDatabase.LoadMainAssetAtPath(depPath);
                if (depObj != null) AccumulateAsset(depObj, visited, ref downloadBytes, ref vramBytes, ref uncompressedBytes);
            }
        }

        /// <summary>
        /// Per-subtree estimate (used when the user selects a specific GameObject).
        /// </summary>
        public static (long downloadBytes, long vramBytes) AnalyzeSubtree(GameObject root)
        {
            if (root == null) return (0, 0);
            var visited = new HashSet<Object>();
            long download = 0;
            long vram = 0;
            long dummy = 0;

            var components = root.GetComponentsInChildren<Component>(true);
            foreach (var comp in components)
            {
                if (comp == null) continue;
                var so = new SerializedObject(comp);
                var sp = so.GetIterator();
                while (sp.NextVisible(true))
                {
                    if (sp.propertyType != SerializedPropertyType.ObjectReference) continue;
                    var obj = sp.objectReferenceValue;
                    if (obj == null) continue;
                    AccumulateAsset(obj, visited, ref download, ref vram, ref dummy);
                }
            }
            var smrs = root.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            foreach (var smr in smrs)
            {
                if (smr != null && smr.sharedMesh != null)
                    AccumulateAsset(smr.sharedMesh, visited, ref download, ref vram, ref dummy);
            }
            var mfs = root.GetComponentsInChildren<MeshFilter>(true);
            foreach (var mf in mfs)
            {
                if (mf != null && mf.sharedMesh != null)
                    AccumulateAsset(mf.sharedMesh, visited, ref download, ref vram, ref dummy);
            }
            return (download, vram);
        }
    }
}

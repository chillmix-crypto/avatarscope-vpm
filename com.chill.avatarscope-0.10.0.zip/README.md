# AvatarScope (com.chill.avatarscope)

VRChatアバター詳細をUnity内で完結可視化するDock型エディタ拡張。

詳細・導入手順は同梱の上位 `README.md` を参照してください。

メニュー: `Tools → AvatarScope → Open Window`
